import React, { useState } from 'react';
import { Database, Copy, Check, X, Shield, Server, Table } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const sqlSchema = `-- =========================================================
-- Millennial Memory Lane: Supabase SQL Schema Blueprint
-- Ready to execute in Supabase SQL Editor
-- =========================================================

-- 1. Create Profiles Table (links to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL,
  handle TEXT UNIQUE NOT NULL,
  avatar_url TEXT,
  banner_url TEXT,
  era_preference TEXT DEFAULT '90s Kid',
  bio TEXT,
  location TEXT,
  favorite_childhood_media JSONB DEFAULT '{}'::jsonb,
  badges TEXT[] DEFAULT '{}',
  aim_away_message TEXT,
  aim_status TEXT DEFAULT 'online',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create Posts Table
CREATE TABLE IF NOT EXISTS public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  image_url TEXT,
  category TEXT DEFAULT 'Nostalgia',
  decade_tag TEXT DEFAULT '90s',
  likes_count INT DEFAULT 0,
  comments_count INT DEFAULT 0,
  community_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Create Meetups Table
CREATE TABLE IF NOT EXISTS public.meetups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  event_date DATE NOT NULL,
  event_time TEXT NOT NULL,
  location TEXT NOT NULL,
  city TEXT NOT NULL,
  max_attendees INT DEFAULT 50,
  cover_image TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Create Meetup Attendees Junction Table
CREATE TABLE IF NOT EXISTS public.meetup_attendees (
  meetup_id UUID REFERENCES public.meetups(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (meetup_id, user_id)
);

-- 5. Create Marketplace Items Table
CREATE TABLE IF NOT EXISTS public.marketplace_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  condition TEXT NOT NULL,
  category TEXT NOT NULL,
  decade TEXT NOT NULL,
  status TEXT DEFAULT 'Available',
  location TEXT NOT NULL,
  image_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meetups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marketplace_items ENABLE ROW LEVEL SECURITY;

-- 7. Basic Public Read Policies
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Public posts are viewable by everyone" ON public.posts FOR SELECT USING (true);
CREATE POLICY "Public meetups are viewable by everyone" ON public.meetups FOR SELECT USING (true);
CREATE POLICY "Public marketplace items are viewable by everyone" ON public.marketplace_items FOR SELECT USING (true);
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopied(true);
    playRetroClickSound();
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#E6FFFA] border-2 border-[#319795] text-[#319795]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-[#319795] flex items-center gap-2">
                Supabase Schema Blueprint
              </h2>
              <p className="text-xs text-slate-600">
                Ready-to-run DDL statements for <code className="text-[#D53F8C] font-bold">profiles</code>, <code className="text-[#D53F8C] font-bold">posts</code>, <code className="text-[#D53F8C] font-bold">meetups</code> & <code className="text-[#D53F8C] font-bold">marketplace_items</code>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-[#D53F8C] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] flex items-start gap-2.5">
              <Table className="w-4 h-4 text-[#D53F8C] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-900">Table Mappings</div>
                <div className="text-[11px] text-slate-600">Includes profiles, posts, meetups, marketplace_items</div>
              </div>
            </div>

            <div className="p-3 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-[#319795] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-900">RLS Policies</div>
                <div className="text-[11px] text-slate-600">Public select enabled for frontend preview query</div>
              </div>
            </div>

            <div className="p-3 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] flex items-start gap-2.5">
              <Server className="w-4 h-4 text-[#D53F8C] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-900">Supabase Client</div>
                <div className="text-[11px] text-slate-600">Direct TypeScript interface matching</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="flex items-center justify-between px-4 py-2 bg-slate-900 text-white rounded-t-lg border-2 border-b-0 border-[#319795] text-xs font-mono">
              <span>SQL Schema DDL</span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1 bg-[#319795] hover:bg-teal-700 text-white font-bold font-sans rounded text-xs transition-all shadow-[2px_2px_0px_0px_#D53F8C]"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL Script'}</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-950 rounded-b-lg border-2 border-[#319795] font-mono text-xs text-teal-300 overflow-x-auto max-h-80 leading-relaxed">
              {sqlSchema}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t-2 border-teal-100 bg-[#F0FFF4] flex items-center justify-between text-xs text-slate-600 font-medium">
          <span>Copy and paste this script into your Supabase SQL Editor.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#319795] text-white rounded-lg font-bold shadow-[2px_2px_0px_0px_#D53F8C] hover:bg-teal-700 transition-colors"
          >
            Close Window
          </button>
        </div>

      </div>
    </div>
  );
};
