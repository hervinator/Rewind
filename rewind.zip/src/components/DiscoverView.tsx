import React, { useState } from 'react';
import { Compass, Volume2, Sparkles, HelpCircle, Flame, RefreshCw, CheckCircle2, Award, Zap } from 'lucide-react';
import { playDialUpSound, playAimLogonSound, playMsnNudgeSound, playGameBoyChime, playRetroClickSound } from '../utils/audio';
import { QUIZ_QUESTIONS } from '../data/mockData';

export const DiscoverView: React.FC = () => {
  // Quiz State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [quizResult, setQuizResult] = useState<string | null>(null);

  // Soundboard state indicator
  const [playingSound, setPlayingSound] = useState<string | null>(null);

  const handleSoundPlay = (soundName: string, soundFn: () => void) => {
    setPlayingSound(soundName);
    soundFn();
    setTimeout(() => setPlayingSound(null), 1200);
  };

  const handleQuizAnswer = (archetype: string) => {
    playRetroClickSound();
    const newAnswers = { ...answers, [currentQuestionIndex]: archetype };
    setAnswers(newAnswers);

    if (currentQuestionIndex < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Calculate winner archetype
      const tally: Record<string, number> = {};
      (Object.values(newAnswers) as string[]).forEach((arch: string) => {
        tally[arch] = (tally[arch] || 0) + 1;
      });
      let maxCount = 0;
      let winner = '90s Dial-Up Devotee';
      Object.entries(tally).forEach(([arch, count]) => {
        if (count > maxCount) {
          maxCount = count;
          winner = arch;
        }
      });
      setQuizResult(winner);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setAnswers({});
    setQuizResult(null);
    playRetroClickSound();
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C]">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
          <Compass className="w-3.5 h-3.5 text-[#D53F8C]" /> Nostalgia Playground
        </div>
        <h1 className="text-2xl font-black text-[#319795] tracking-tight">
          Discover Retro Memories & Soundboard
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
          Listen to iconic 90s/2000s tech sound effects, take our instant nostalgia persona quiz, and explore trending retro topics!
        </p>
      </div>

      {/* Retro Interactive Web Audio Soundboard */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#319795] space-y-4">
        <div className="flex items-center justify-between border-b-2 border-teal-100 pb-3">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-[#D53F8C] animate-pulse" />
            <h2 className="text-base font-black text-[#319795]">
              Interactive 90s & Y2K Soundboard
            </h2>
          </div>
          <span className="text-[11px] font-mono font-bold text-[#319795] bg-[#E6FFFA] border border-[#319795] px-2 py-0.5 rounded">
            Web Audio API Synthesized
          </span>
        </div>

        <p className="text-xs text-slate-600 font-medium">
          Click any button below to trigger synthesized retro sound effects straight from your speakers!
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          
          <button
            onClick={() => handleSoundPlay('DialUp', playDialUpSound)}
            className={`p-4 rounded-lg border-2 transition-all text-left flex flex-col justify-between h-28 group ${
              playingSound === 'DialUp'
                ? 'bg-[#D53F8C] border-[#319795] text-white shadow-[2px_2px_0px_0px_#319795]'
                : 'bg-[#F0FFF4] hover:bg-teal-50 border-[#319795] text-slate-900 shadow-[2px_2px_0px_0px_#D53F8C]'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">📟</span>
              <Volume2 className={`w-4 h-4 ${playingSound === 'DialUp' ? 'text-white' : 'text-[#319795]'} group-hover:scale-110 transition-transform`} />
            </div>
            <div>
              <div className="font-bold text-xs">56k Dial-Up Modem</div>
              <div className={`text-[10px] ${playingSound === 'DialUp' ? 'text-white/80' : 'text-slate-500'}`}>Handshake Screech</div>
            </div>
          </button>

          <button
            onClick={() => handleSoundPlay('AIM', playAimLogonSound)}
            className={`p-4 rounded-lg border-2 transition-all text-left flex flex-col justify-between h-28 group ${
              playingSound === 'AIM'
                ? 'bg-[#D53F8C] border-[#319795] text-white shadow-[2px_2px_0px_0px_#319795]'
                : 'bg-[#F0FFF4] hover:bg-teal-50 border-[#319795] text-slate-900 shadow-[2px_2px_0px_0px_#D53F8C]'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">🚪</span>
              <Volume2 className={`w-4 h-4 ${playingSound === 'AIM' ? 'text-white' : 'text-[#319795]'} group-hover:scale-110 transition-transform`} />
            </div>
            <div>
              <div className="font-bold text-xs">AIM Door Logon</div>
              <div className={`text-[10px] ${playingSound === 'AIM' ? 'text-white/80' : 'text-slate-500'}`}>AOL Door Chime</div>
            </div>
          </button>

          <button
            onClick={() => handleSoundPlay('MSN', playMsnNudgeSound)}
            className={`p-4 rounded-lg border-2 transition-all text-left flex flex-col justify-between h-28 group ${
              playingSound === 'MSN'
                ? 'bg-[#D53F8C] border-[#319795] text-white shadow-[2px_2px_0px_0px_#319795]'
                : 'bg-[#F0FFF4] hover:bg-teal-50 border-[#319795] text-slate-900 shadow-[2px_2px_0px_0px_#D53F8C]'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">💬</span>
              <Volume2 className={`w-4 h-4 ${playingSound === 'MSN' ? 'text-white' : 'text-[#319795]'} group-hover:scale-110 transition-transform`} />
            </div>
            <div>
              <div className="font-bold text-xs">MSN Nudge Alert</div>
              <div className={`text-[10px] ${playingSound === 'MSN' ? 'text-white/80' : 'text-slate-500'}`}>Window Shake Buzz</div>
            </div>
          </button>

          <button
            onClick={() => handleSoundPlay('GB', playGameBoyChime)}
            className={`p-4 rounded-lg border-2 transition-all text-left flex flex-col justify-between h-28 group ${
              playingSound === 'GB'
                ? 'bg-[#D53F8C] border-[#319795] text-white shadow-[2px_2px_0px_0px_#319795]'
                : 'bg-[#F0FFF4] hover:bg-teal-50 border-[#319795] text-slate-900 shadow-[2px_2px_0px_0px_#D53F8C]'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">🎮</span>
              <Volume2 className={`w-4 h-4 ${playingSound === 'GB' ? 'text-white' : 'text-[#319795]'} group-hover:scale-110 transition-transform`} />
            </div>
            <div>
              <div className="font-bold text-xs">Game Boy Chime</div>
              <div className={`text-[10px] ${playingSound === 'GB' ? 'text-white/80' : 'text-slate-500'}`}>Startup Ding Bell</div>
            </div>
          </button>

        </div>
      </div>

      {/* Pop Culture Persona Quiz */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#D53F8C] space-y-4">
        <div className="flex items-center justify-between border-b-2 border-teal-100 pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-[#D53F8C]" />
            <h2 className="text-base font-black text-[#319795]">
              Nostalgia Persona Quiz: Which 90s/2000s Icon Are You?
            </h2>
          </div>
          <span className="text-xs font-mono font-bold text-[#D53F8C]">
            Question {currentQuestionIndex + 1} of {QUIZ_QUESTIONS.length}
          </span>
        </div>

        {quizResult ? (
          <div className="p-6 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] text-center space-y-3">
            <Award className="w-12 h-12 text-[#D53F8C] mx-auto animate-bounce" />
            <div className="text-xs font-mono uppercase tracking-wider font-bold text-[#319795]">
              Your Nostalgia Archetype Result:
            </div>
            <h3 className="text-2xl font-black text-[#D53F8C]">
              {quizResult}
            </h3>
            <p className="text-xs text-slate-700 max-w-md mx-auto leading-relaxed font-medium">
              You embody pure 90s/Y2K magic! Your childhood was defined by authentic analog tech, iconic cartoons, and unforgettable pop culture moments.
            </p>
            <button
              onClick={resetQuiz}
              className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-[#319795] text-white font-bold text-xs rounded-lg hover:bg-teal-700 transition-all shadow-[2px_2px_0px_0px_#D53F8C]"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Take Quiz Again</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              {QUIZ_QUESTIONS[currentQuestionIndex].question}
            </h3>

            <div className="space-y-2">
              {QUIZ_QUESTIONS[currentQuestionIndex].options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuizAnswer(opt.archetype)}
                  className="w-full p-3 bg-[#F0FFF4] hover:bg-teal-50 border-2 border-[#319795] rounded-lg text-left text-xs text-slate-900 font-bold transition-all flex items-center justify-between group shadow-sm"
                >
                  <span>{opt.text}</span>
                  <CheckCircle2 className="w-4 h-4 text-[#319795] group-hover:text-[#D53F8C] transition-colors" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Trending Topics & Today in Nostalgia History Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Trending Nostalgia Topics */}
        <div className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[2px_2px_0px_0px_#319795] space-y-3">
          <div className="flex items-center gap-2 text-[#D53F8C] font-black text-sm border-b-2 border-teal-100 pb-2">
            <Flame className="w-4 h-4" /> Trending Nostalgia Hashtags
          </div>
          <div className="space-y-2 text-xs">
            {[
              { tag: '#BlockbusterFriday', posts: '14.2k memories' },
              { tag: '#AIMAwayMessages', posts: '9.8k memories' },
              { tag: '#SNESvsGenesis', posts: '8.1k memories' },
              { tag: '#DunkaroosForever', posts: '6.4k memories' },
              { tag: '#SnakeIIHighScore', posts: '5.2k memories' }
            ].map((t, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-[#F0FFF4] border border-[#319795]">
                <span className="font-bold text-[#319795] font-mono">{t.tag}</span>
                <span className="text-[11px] text-slate-500 font-medium">{t.posts}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Today in 1999 History */}
        <div className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[2px_2px_0px_0px_#319795] space-y-3">
          <div className="flex items-center gap-2 text-[#319795] font-black text-sm border-b-2 border-teal-100 pb-2">
            <Zap className="w-4 h-4 text-[#D53F8C]" /> On This Day in Nostalgia History
          </div>
          <div className="p-3 bg-[#F0FFF4] rounded-lg border border-[#319795] text-xs space-y-2">
            <div className="text-[10px] font-mono font-bold text-[#D53F8C] uppercase">August 1999</div>
            <p className="text-slate-800 leading-relaxed font-medium">
              Super Smash Bros 64 was topping game rental charts, the iPod was still 2 years away from invention, and millions of kids were collecting Pokemon 1st Edition base set booster packs!
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
