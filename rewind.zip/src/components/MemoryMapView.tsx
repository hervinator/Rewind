import React, { useState } from 'react';
import { MapPin, Sparkles, Plus, Heart, MessageSquare, Compass, Filter, Calendar, X, Send } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';

interface MemoryPin {
  id: string;
  title: string;
  location: string;
  city: string;
  decade: '90s' | '2000s';
  category: 'Arcade & Gaming' | 'Music & Video Store' | 'Mall Hangout' | 'Concert Venue' | 'Fast Food & Diners';
  year: string;
  story: string;
  image_url: string;
  author: string;
  avatar_url: string;
  likes: number;
  user_liked?: boolean;
  comments_count: number;
  coordinates: { x: number; y: number }; // Percentage on map canvas
}

const INITIAL_PINS: MemoryPin[] = [
  {
    id: 'pin_1',
    title: 'Blockbuster Video Store #412',
    location: 'Westlake Shopping Center',
    city: 'Austin, TX',
    decade: '90s',
    category: 'Music & Video Store',
    year: '1998',
    story: 'Friday nights renting N64 games (GoldenEye & Mario Kart 64) and getting a box of Buncha Crunch and popcorn. Remembering the blue and yellow carpet smell!',
    image_url: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=800&q=80',
    author: 'Sarah (CyberChic99)',
    avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    likes: 142,
    user_liked: true,
    comments_count: 28,
    coordinates: { x: 25, y: 35 }
  },
  {
    id: 'pin_2',
    title: 'Aladdin’s Castle Arcade',
    location: 'Oakridge Mall Galleria',
    city: 'San Jose, CA',
    decade: '90s',
    category: 'Arcade & Gaming',
    year: '1996',
    story: 'Pumping brass tokens into Street Fighter II Turbo and Dance Dance Revolution 3rdMIX. Crowds gathering around the cabinet cheering on top streaks!',
    image_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
    author: 'Alex (NeonRider88)',
    avatar_url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    likes: 210,
    user_liked: false,
    comments_count: 45,
    coordinates: { x: 55, y: 28 }
  },
  {
    id: 'pin_3',
    title: 'Sam Goody CD & Cassette Listening Station',
    location: 'Paramus Park Mall',
    city: 'Paramus, NJ',
    decade: '2000s',
    category: 'Music & Video Store',
    year: '2001',
    story: 'Putting on those oversized vinyl headphones at Sam Goody to preview Linkin Park Hybrid Theory and Blink-182 Take Off Your Pants and Jacket.',
    image_url: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    author: 'Mikey (EmoKid2003)',
    avatar_url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80',
    likes: 98,
    user_liked: false,
    comments_count: 14,
    coordinates: { x: 78, y: 52 }
  },
  {
    id: 'pin_4',
    title: 'Planet Hollywood & Movie Prop Exhibit',
    location: 'Times Square',
    city: 'New York, NY',
    decade: '90s',
    category: 'Fast Food & Diners',
    year: '1999',
    story: 'Eating cap’n crunch chicken fingers while staring at Terminator endoskeleton props and movie posters on the wall!',
    image_url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    author: 'Jessica (Y2K_Princess)',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    likes: 175,
    user_liked: true,
    comments_count: 31,
    coordinates: { x: 82, y: 30 }
  },
  {
    id: 'pin_5',
    title: 'Warped Tour 2004 Main Stage',
    location: 'Gorge Amphitheatre',
    city: 'George, WA',
    decade: '2000s',
    category: 'Concert Venue',
    year: '2004',
    story: 'Inflatable schedule towers, sharpie autographs, buying band t-shirts at tents, and crowd surfing during My Chemical Romance & Coheed and Cambria.',
    image_url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    author: 'Dave (PopPunkForever)',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    likes: 312,
    user_liked: false,
    comments_count: 67,
    coordinates: { x: 18, y: 22 }
  }
];

export const MemoryMapView: React.FC = () => {
  const [pins, setPins] = useState<MemoryPin[]>(INITIAL_PINS);
  const [selectedPin, setSelectedPin] = useState<MemoryPin | null>(INITIAL_PINS[0]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDecade, setSelectedDecade] = useState<string>('All');
  const [isAddPinModalOpen, setIsAddPinModalOpen] = useState<boolean>(false);

  // New Pin Form State
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState('');
  const [decade, setDecade] = useState<'90s' | '2000s'>('90s');
  const [category, setCategory] = useState<MemoryPin['category']>('Arcade & Gaming');
  const [year, setYear] = useState('1999');
  const [story, setStory] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const filteredPins = pins.filter((p) => {
    if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
    if (selectedDecade !== 'All' && p.decade !== selectedDecade) return false;
    return true;
  });

  const handleLikePin = (pinId: string) => {
    playRetroClickSound();
    setPins((prev) =>
      prev.map((p) => {
        if (p.id === pinId) {
          const newLiked = !p.user_liked;
          return {
            ...p,
            user_liked: newLiked,
            likes: newLiked ? p.likes + 1 : p.likes - 1
          };
        }
        return p;
      })
    );

    if (selectedPin && selectedPin.id === pinId) {
      const newLiked = !selectedPin.user_liked;
      setSelectedPin({
        ...selectedPin,
        user_liked: newLiked,
        likes: newLiked ? selectedPin.likes + 1 : selectedPin.likes - 1
      });
    }
  };

  const handleAddPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !location) return;

    // Random placement on coordinates for demonstration
    const newX = Math.floor(Math.random() * 70) + 15;
    const newY = Math.floor(Math.random() * 60) + 20;

    const newPin: MemoryPin = {
      id: `pin_${Date.now()}`,
      title,
      location,
      city: city || 'Local Hometown',
      decade,
      category,
      year: year || '1999',
      story,
      image_url: imageUrl || 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
      author: 'You (RetroExplorer)',
      avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      likes: 1,
      user_liked: true,
      comments_count: 0,
      coordinates: { x: newX, y: newY }
    };

    setPins([newPin, ...pins]);
    setSelectedPin(newPin);
    setIsAddPinModalOpen(false);
    playRetroClickSound();

    // Reset Form
    setTitle('');
    setLocation('');
    setCity('');
    setStory('');
    setImageUrl('');
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#D53F8C]" /> Nostalgic Geo-Memory Explorer
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            Interactive Nostalgia Memory Map 🗺️
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            Discover and drop memory pins at iconic 90s & Y2K hangouts: Blockbusters, mall arcades, Sam Goody stores, roller rinks, and concert venues!
          </p>
        </div>

        <button
          onClick={() => {
            setIsAddPinModalOpen(true);
            playRetroClickSound();
          }}
          className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#319795] hover:bg-teal-700 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all transform hover:-translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          <span>Drop Memory Pin</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white border-2 border-[#319795] rounded-xl p-3 shadow-[2px_2px_0px_0px_#319795]">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 no-scrollbar">
          <span className="text-xs font-mono font-bold text-[#319795] px-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#D53F8C]" /> Filter:
          </span>
          {['All', 'Arcade & Gaming', 'Music & Video Store', 'Mall Hangout', 'Concert Venue', 'Fast Food & Diners'].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                playRetroClickSound();
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
                selectedCategory === cat
                  ? 'bg-[#319795] text-white border-[#319795] shadow-[2px_2px_0px_0px_#D53F8C]'
                  : 'bg-[#F0FFF4] border-[#319795] text-[#319795] hover:bg-teal-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 bg-[#F0FFF4] p-1 rounded-lg border-2 border-[#319795]">
          {['All', '90s', '2000s'].map((dec) => (
            <button
              key={dec}
              onClick={() => {
                setSelectedDecade(dec);
                playRetroClickSound();
              }}
              className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                selectedDecade === dec
                  ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                  : 'text-[#319795] hover:bg-teal-50'
              }`}
            >
              {dec}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map + Card Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interactive Map Visualizer Canvas */}
        <div className="lg:col-span-2 bg-[#F0FFF4] border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795] p-4 relative min-h-[420px] flex flex-col justify-between overflow-hidden">
          
          {/* Map Top Header */}
          <div className="flex items-center justify-between border-b-2 border-teal-100 pb-2 z-10 bg-white/80 backdrop-blur-sm p-2 rounded-lg border border-[#319795]">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#D53F8C]" />
              <span className="font-mono text-xs font-bold text-[#319795] uppercase">
                Interactive Map Grid ({filteredPins.length} Pins Found)
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-500 font-bold">
              Click pins on map to inspect
            </span>
          </div>

          {/* Styled Geographic Canvas Area */}
          <div className="relative w-full h-[360px] my-3 rounded-lg overflow-hidden bg-emerald-50/50 border-2 border-dashed border-[#319795] flex items-center justify-center">
            
            {/* Grid Overlay Lines */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#31979515_1px,transparent_1px),linear-gradient(to_bottom,#31979515_1px,transparent_1px)] bg-[size:24px_24px]" />

            {/* Stylized Map Regions Labels */}
            <span className="absolute top-4 left-6 text-[10px] font-mono font-bold text-teal-800/40 uppercase tracking-widest">Pacific Coast</span>
            <span className="absolute top-4 right-6 text-[10px] font-mono font-bold text-teal-800/40 uppercase tracking-widest">East Coast Arcades</span>
            <span className="absolute bottom-4 left-1/3 text-[10px] font-mono font-bold text-teal-800/40 uppercase tracking-widest">Mall Belt Zone</span>

            {/* Interactive Pins */}
            {filteredPins.map((pin) => {
              const isSelected = selectedPin?.id === pin.id;

              return (
                <button
                  key={pin.id}
                  onClick={() => {
                    setSelectedPin(pin);
                    playRetroClickSound();
                  }}
                  style={{ left: `${pin.coordinates.x}%`, top: `${pin.coordinates.y}%` }}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all group z-20 focus:outline-none`}
                >
                  <div className={`relative flex flex-col items-center`}>
                    {/* Pulsing Pin Marker */}
                    <div
                      className={`p-2 rounded-full border-2 transition-all ${
                        isSelected
                          ? 'bg-[#D53F8C] border-white scale-125 shadow-[0_0_15px_#D53F8C]'
                          : 'bg-[#319795] border-white hover:scale-110 shadow-md'
                      }`}
                    >
                      <MapPin className="w-4 h-4 text-white" />
                    </div>

                    {/* Pin Tooltip */}
                    <span
                      className={`mt-1 px-2 py-0.5 rounded font-mono text-[10px] font-bold whitespace-nowrap border shadow-sm transition-all ${
                        isSelected
                          ? 'bg-slate-900 text-white border-[#D53F8C]'
                          : 'bg-white text-[#319795] border-[#319795] opacity-90 group-hover:opacity-100'
                      }`}
                    >
                      {pin.title}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Map Footer Note */}
          <div className="text-[11px] font-mono text-center text-[#319795] font-bold bg-white p-2 rounded-lg border border-[#319795]">
            💡 Pro-Tip: Tap any icon above to view authentic 90s/Y2K memories geotagged by members!
          </div>
        </div>

        {/* Selected Pin Detailed Card */}
        <div className="lg:col-span-1">
          {selectedPin ? (
            <div className="bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#D53F8C] space-y-4 flex flex-col justify-between h-full">
              <div>
                {/* Photo & Badge */}
                <div className="relative h-48 bg-slate-100 border-b-2 border-[#319795]">
                  <img
                    src={selectedPin.image_url}
                    alt={selectedPin.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold uppercase rounded-full bg-white border-2 border-[#319795] text-[#319795]">
                      {selectedPin.decade}
                    </span>
                    <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold rounded-full bg-[#D53F8C] text-white border border-white">
                      {selectedPin.year}
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <div>
                    <h3 className="text-lg font-black text-slate-900 leading-snug">
                      {selectedPin.title}
                    </h3>
                    <p className="text-xs font-bold text-[#319795] flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#D53F8C]" />
                      <span>{selectedPin.location}, {selectedPin.city}</span>
                    </p>
                  </div>

                  {/* Story */}
                  <p className="text-xs text-slate-700 leading-relaxed font-medium bg-[#F0FFF4] p-3 rounded-lg border border-[#319795]">
                    "{selectedPin.story}"
                  </p>

                  {/* Author */}
                  <div className="flex items-center justify-between text-xs pt-2 border-t-2 border-teal-100">
                    <div className="flex items-center gap-2">
                      <img
                        src={selectedPin.avatar_url}
                        alt={selectedPin.author}
                        className="w-6 h-6 rounded-full object-cover ring-2 ring-[#D53F8C]"
                      />
                      <span className="text-slate-600 font-bold text-[11px]">
                        Pinned by: <strong className="text-slate-900">{selectedPin.author}</strong>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="p-4 bg-[#F0FFF4] border-t-2 border-teal-100 flex items-center justify-between">
                <button
                  onClick={() => handleLikePin(selectedPin.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg font-bold text-xs transition-all ${
                    selectedPin.user_liked
                      ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                      : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${selectedPin.user_liked ? 'fill-white' : ''}`} />
                  <span>{selectedPin.likes} Likes</span>
                </button>

                <div className="flex items-center gap-1 text-xs font-bold text-[#319795] font-mono">
                  <MessageSquare className="w-4 h-4 text-[#D53F8C]" />
                  <span>{selectedPin.comments_count} memories shared</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border-2 border-[#319795] rounded-xl p-8 text-center text-slate-600 font-medium">
              Select a pin on the map to view nostalgic details!
            </div>
          )}
        </div>
      </div>

      {/* Add Memory Pin Modal */}
      {isAddPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-lg shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#D53F8C]" />
                <h2 className="text-lg font-black text-[#319795]">Drop a Memory Pin on the Map</h2>
              </div>
              <button
                onClick={() => setIsAddPinModalOpen(false)}
                className="p-1 text-slate-400 hover:text-[#D53F8C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddPinSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Place / Spot Name</label>
                <input
                  type="text"
                  placeholder="e.g. FunColand Games or Roller Skating Arena"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Location / Mall</label>
                  <input
                    type="text"
                    placeholder="e.g. Galleria Mall"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">City, State</label>
                  <input
                    type="text"
                    placeholder="e.g. Austin, TX"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Decade</label>
                  <select
                    value={decade}
                    onChange={(e) => setDecade(e.target.value as '90s' | '2000s')}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="90s">90s</option>
                    <option value="2000s">2000s</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as MemoryPin['category'])}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="Arcade & Gaming">Arcade & Gaming</option>
                    <option value="Music & Video Store">Music & Video Store</option>
                    <option value="Mall Hangout">Mall Hangout</option>
                    <option value="Concert Venue">Concert Venue</option>
                    <option value="Fast Food & Diners">Fast Food & Diners</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Specific Year</label>
                  <input
                    type="text"
                    placeholder="e.g. 1999"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Nostalgic Story / Memory</label>
                <textarea
                  rows={3}
                  placeholder="Describe what you remembered doing here, smells, songs playing, snacks..."
                  value={story}
                  onChange={(e) => setStory(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Photo URL (Optional)</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsAddPinModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Pin Memory</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
