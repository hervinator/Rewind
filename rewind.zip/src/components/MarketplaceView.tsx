import React, { useState } from 'react';
import { MarketplaceItem, Profile } from '../types';
import { ShoppingBag, Tag, MessageSquare, Plus, Sparkles, Filter, X, Send } from 'lucide-react';
import { formatCurrency, formatRelativeTime } from '../utils/dateFormatter';
import { playRetroClickSound } from '../utils/audio';

interface MarketplaceViewProps {
  items: MarketplaceItem[];
  currentUser: Profile;
  onMessageSeller: (sellerId: string, sellerName: string, itemTitle: string) => void;
  onAddItem: (itemData: Omit<MarketplaceItem, 'id' | 'status' | 'created_at'>) => void;
  searchQuery?: string;
}

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({
  items,
  currentUser,
  onMessageSeller,
  onAddItem,
  searchQuery = ''
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDecade, setSelectedDecade] = useState<string>('All');
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [condition, setCondition] = useState<MarketplaceItem['condition']>('Gently Used');
  const [category, setCategory] = useState<MarketplaceItem['category']>('Gaming');
  const [decade, setDecade] = useState<MarketplaceItem['decade']>('90s');
  const [location, setLocation] = useState('Austin, TX');
  const [imageUrl, setImageUrl] = useState('');

  const filteredItems = items.filter((item) => {
    if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
    if (selectedDecade !== 'All' && item.decade !== selectedDecade && item.decade !== 'Both') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.seller.username.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleSellSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !price || !imageUrl.trim()) return;

    onAddItem({
      title: title.trim(),
      description: description.trim(),
      price: parseFloat(price) || 20,
      condition,
      category,
      decade,
      location: location.trim() || 'Austin, TX',
      imageUrl: imageUrl.trim(),
      seller: {
        id: currentUser.id,
        username: currentUser.username,
        handle: currentUser.handle,
        avatar_url: currentUser.avatar_url,
        rating: 5.0
      }
    });

    playRetroClickSound();
    setIsSellModalOpen(false);
    // Reset
    setTitle('');
    setDescription('');
    setPrice('');
    setImageUrl('');
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <ShoppingBag className="w-3.5 h-3.5 text-[#D53F8C]" /> Retro Flea Market & Trading Post
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            Nostalgic Marketplace
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            Buy, sell, or trade authentic 90s & Y2K memorabilia: Game Boy Colors, Furbies, Blockbuster VHS tapes, iPods, and retro cereal boxes!
          </p>
        </div>

        <button
          onClick={() => {
            setIsSellModalOpen(true);
            playRetroClickSound();
          }}
          className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#319795] hover:bg-teal-700 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all transform hover:-translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          <span>Sell an Item</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white border-2 border-[#319795] rounded-xl p-3 shadow-[2px_2px_0px_0px_#319795]">
        
        {/* Category Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 no-scrollbar">
          <span className="text-xs font-mono font-bold text-[#319795] px-2 flex items-center gap-1">
            <Filter className="w-3 h-3 text-[#D53F8C]" /> Category:
          </span>
          {['All', 'Gaming', 'Toys & Collectibles', 'Music & Media', 'Retro Tech'].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                playRetroClickSound();
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
                selectedCategory === cat
                  ? 'bg-[#319795] text-white border-[#319795] shadow-[2px_2px_0px_0px_#D53F8C]'
                  : 'bg-[#F0FFF4] border-[#319795] text-[#319795] hover:bg-teal-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Decade Filter */}
        <div className="flex items-center gap-1.5 bg-[#F0FFF4] p-1 rounded-lg border-2 border-[#319795]">
          {['All', '90s', '2000s'].map((dec) => (
            <button
              key={dec}
              onClick={() => {
                setSelectedDecade(dec);
                playRetroClickSound();
              }}
              className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                selectedDecade === dec
                  ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                  : 'text-[#319795] hover:bg-teal-50'
              }`}
            >
              {dec}
            </button>
          ))}
        </div>

      </div>

      {/* Marketplace Grid */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-12 px-4 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795]">
          <Sparkles className="w-8 h-8 text-[#D53F8C] mx-auto mb-2" />
          <h3 className="text-slate-900 font-bold text-base">No nostalgic items found</h3>
          <p className="text-slate-600 text-xs mt-1">Be the first to list a retro collectible!</p>
          <button
            onClick={() => setIsSellModalOpen(true)}
            className="mt-4 px-4 py-2 bg-[#319795] text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
          >
            Sell Nostalgic Item
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#319795] flex flex-col justify-between transition-all group"
            >
              <div>
                {/* Product Image & Price Tag */}
                <div className="relative h-52 overflow-hidden bg-slate-100 border-b-2 border-[#319795]">
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-60" />

                  {/* Price Tag Badge */}
                  <div className="absolute top-3 right-3 px-3 py-1 bg-[#D53F8C] text-white font-black text-sm rounded-full shadow-[2px_2px_0px_0px_#319795] border border-white">
                    {formatCurrency(item.price)}
                  </div>

                  {/* Condition & Decade Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1">
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-white border-2 border-[#319795] text-[#319795]">
                      {item.decade}
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-white border-2 border-[#319795] text-[#D53F8C]">
                      {item.condition}
                    </span>
                  </div>
                </div>

                {/* Details Section */}
                <div className="p-4 space-y-2.5">
                  <h3 className="font-black text-slate-900 text-base leading-snug line-clamp-2">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3 font-medium">
                    {item.description}
                  </p>

                  <div className="pt-2 border-t-2 border-teal-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <img
                        src={item.seller.avatar_url}
                        alt={item.seller.username}
                        className="w-6 h-6 rounded-full object-cover ring-2 ring-[#D53F8C]"
                      />
                      <span className="text-slate-800 font-bold truncate max-w-[120px]">
                        {item.seller.username}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono font-bold text-[#319795]">
                      {item.location} • {formatRelativeTime(item.created_at)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Message Seller Button */}
              <div className="p-4 bg-[#F0FFF4] border-t-2 border-teal-100">
                <button
                  onClick={() => {
                    onMessageSeller(item.seller.id, item.seller.username, item.title);
                    playRetroClickSound();
                  }}
                  className="w-full py-2.5 px-4 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-2 shadow-[2px_2px_0px_0px_#D53F8C] transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Message Seller (AIM Instant Chat)</span>
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Sell Item Modal */}
      {isSellModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-lg shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-[#D53F8C]" />
                <h2 className="text-lg font-black text-[#319795]">List Nostalgic Item for Sale</h2>
              </div>
              <button
                onClick={() => setIsSellModalOpen(false)}
                className="p-1 text-slate-400 hover:text-[#D53F8C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSellSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Item Title</label>
                <input
                  type="text"
                  placeholder="e.g. Lime Green Game Boy Color with Pokemon Yellow"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="Describe condition, missing parts, nostalgic backstory, functionality..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Price ($ USD)</label>
                  <input
                    type="number"
                    placeholder="e.g. 75"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Condition</label>
                  <select
                    value={condition}
                    onChange={(e) => setCondition(e.target.value as MarketplaceItem['condition'])}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="Mint in Box">Mint in Box</option>
                    <option value="Like New">Like New</option>
                    <option value="Gently Used">Gently Used</option>
                    <option value="Well Loved">Well Loved</option>
                    <option value="Refurbished">Refurbished</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as MarketplaceItem['category'])}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="Gaming">Gaming</option>
                    <option value="Toys & Collectibles">Toys & Collectibles</option>
                    <option value="Music & Media">Music & Media</option>
                    <option value="Apparel & Accessories">Apparel & Accessories</option>
                    <option value="Retro Tech">Retro Tech</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Decade</label>
                  <select
                    value={decade}
                    onChange={(e) => setDecade(e.target.value as MarketplaceItem['decade'])}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="90s">90s</option>
                    <option value="2000s">2000s</option>
                    <option value="Both">Both / Hybrid</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Location / City</label>
                <input
                  type="text"
                  placeholder="e.g. Austin, TX"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Photo URL</label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/..."
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsSellModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>List Item</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
