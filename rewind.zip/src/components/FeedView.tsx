import React, { useState } from 'react';
import { Post, Profile, PostCategory, DecadeTag } from '../types';
import { Heart, MessageSquare, Share2, Sparkles, Filter, Plus, Send, Radio } from 'lucide-react';
import { formatRelativeTime } from '../utils/dateFormatter';
import { playRetroClickSound } from '../utils/audio';

interface FeedViewProps {
  posts: Post[];
  currentUser: Profile;
  onLikePost: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
  onOpenCreatePost: () => void;
  searchQuery?: string;
}

export const FeedView: React.FC<FeedViewProps> = ({
  posts,
  currentUser,
  onLikePost,
  onAddComment,
  onOpenCreatePost,
  searchQuery = ''
}) => {
  const [selectedDecade, setSelectedDecade] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<string>('');
  const [shareToastPostId, setShareToastPostId] = useState<string | null>(null);

  const categories: string[] = ['All', 'Nostalgia', 'Tech & Toys', 'Movies & TV', 'Gaming', 'Music', 'Snacks & Food'];
  const decades: string[] = ['All', '90s', '2000s'];

  const filteredPosts = posts.filter((post) => {
    // Decade filter
    if (selectedDecade !== 'All' && post.decade_tag !== selectedDecade && post.decade_tag !== 'Both') {
      return false;
    }
    // Category filter
    if (selectedCategory !== 'All' && post.category !== selectedCategory) {
      return false;
    }
    // Search query filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const contentMatch = post.content.toLowerCase().includes(query);
      const authorMatch = post.author.username.toLowerCase().includes(query);
      const categoryMatch = post.category.toLowerCase().includes(query);
      return contentMatch || authorMatch || categoryMatch;
    }
    return true;
  });

  const handleCommentSubmit = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    onAddComment(postId, commentInput.trim());
    setCommentInput('');
    playRetroClickSound();
  };

  const handleShare = (postId: string) => {
    setShareToastPostId(postId);
    playRetroClickSound();
    setTimeout(() => setShareToastPostId(null), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Feed Hero Banner / Share Prompt Card */}
      <div className="relative overflow-hidden bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#D53F8C]">
        <div className="absolute right-0 top-0 w-64 h-full opacity-10 pointer-events-none bg-[radial-gradient(#319795_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold">
              <Radio className="w-3.5 h-3.5 animate-pulse text-[#D53F8C]" />
              <span>Nostalgia Broadcast Feed</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-[#319795] tracking-tight">
              What classic memory is living rent-free in your head today?
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              Share your favorite 90s toys, Y2K AIM away messages, SNES cheat codes, or cassette mixtapes.
            </p>
          </div>

          <button
            onClick={() => {
              onOpenCreatePost();
              playRetroClickSound();
            }}
            className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#319795] hover:bg-teal-700 text-white font-black text-sm rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <Plus className="w-4 h-4" />
            <span>Share Memory</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white border-2 border-[#319795] rounded-xl p-3 shadow-[2px_2px_0px_0px_#319795]">
        
        {/* Decade Filter */}
        <div className="flex items-center gap-1.5 bg-[#F0FFF4] p-1 rounded-lg border border-[#319795] w-full sm:w-auto">
          <span className="text-xs font-mono font-bold text-[#319795] px-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#D53F8C]" /> Decade:
          </span>
          {decades.map((dec) => (
            <button
              key={dec}
              onClick={() => {
                setSelectedDecade(dec);
                playRetroClickSound();
              }}
              className={`flex-1 sm:flex-none px-3 py-1 rounded text-xs font-bold transition-all ${
                selectedDecade === dec
                  ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                  : 'text-[#319795] hover:bg-teal-50'
              }`}
            >
              {dec}
            </button>
          ))}
        </div>

        {/* Category Scroll Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                playRetroClickSound();
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
                selectedCategory === cat
                  ? 'bg-[#D53F8C] text-white border-[#319795] shadow-[2px_2px_0px_0px_#319795]'
                  : 'bg-[#F0FFF4] border-[#319795] text-[#319795] hover:bg-teal-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Posts Feed Stack */}
      {filteredPosts.length === 0 ? (
        <div className="text-center py-12 px-4 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795]">
          <Sparkles className="w-8 h-8 text-[#D53F8C] mx-auto mb-2" />
          <h3 className="text-[#319795] font-black text-base">No memories found for this filter</h3>
          <p className="text-slate-500 text-xs mt-1">Try selecting 'All' or be the first to post a memory!</p>
          <button
            onClick={onOpenCreatePost}
            className="mt-4 px-4 py-2 bg-[#319795] text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
          >
            Post First Memory
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const isCommentsOpen = activeCommentPostId === post.id;

            return (
              <article
                key={post.id}
                className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#D53F8C] transition-all"
              >
                {/* Author Bar */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.author.avatar_url}
                      alt={post.author.username}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-[#D53F8C]"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{post.author.username}</span>
                        <span className="text-xs text-slate-500">{post.author.handle}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="px-1.5 py-0.5 text-[10px] font-mono rounded bg-[#E6FFFA] border border-[#319795] text-[#319795] font-bold">
                          {post.author.era_preference}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">• {formatRelativeTime(post.created_at)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Decade & Category Badges */}
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-[#D53F8C] text-white">
                      {post.decade_tag}
                    </span>
                    <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-[#F0FFF4] text-[#319795] border border-[#319795]">
                      {post.category}
                    </span>
                  </div>
                </div>

                {/* Post Content Body */}
                <p className="text-slate-800 text-sm leading-relaxed whitespace-pre-line mb-3 font-medium">
                  {post.content}
                </p>

                {/* Optional Image */}
                {post.image_url && (
                  <div className="mb-4 rounded-lg overflow-hidden border-2 border-[#319795] bg-[#F0FFF4] max-h-96 flex items-center justify-center">
                    <img
                      src={post.image_url}
                      alt="Memory media"
                      className="w-full h-full object-cover hover:scale-102 transition-transform duration-500"
                    />
                  </div>
                )}

                {/* Action Bar (Like, Comment, Share) */}
                <div className="flex items-center justify-between pt-3 border-t-2 border-teal-100 text-xs">
                  <div className="flex items-center gap-3">
                    
                    {/* Like Button */}
                    <button
                      onClick={() => {
                        onLikePost(post.id);
                        playRetroClickSound();
                      }}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
                        post.user_liked
                          ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                          : 'bg-[#F0FFF4] text-[#319795] border border-[#319795] hover:bg-teal-50'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          post.user_liked ? 'fill-white text-white scale-110' : 'text-[#D53F8C]'
                        }`}
                      />
                      <span>{post.likes_count}</span>
                    </button>

                    {/* Comment Toggle Button */}
                    <button
                      onClick={() => {
                        setActiveCommentPostId(isCommentsOpen ? null : post.id);
                        playRetroClickSound();
                      }}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
                        isCommentsOpen
                          ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                          : 'bg-[#F0FFF4] text-[#319795] border border-[#319795] hover:bg-teal-50'
                      }`}
                    >
                      <MessageSquare className="w-4 h-4 text-[#319795]" />
                      <span>{post.comments.length} Comments</span>
                    </button>
                  </div>

                  {/* Share Action */}
                  <div className="relative">
                    <button
                      onClick={() => handleShare(post.id)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-[#F0FFF4] text-[#319795] border border-[#319795] hover:bg-teal-50 rounded-lg font-bold transition-all"
                    >
                      <Share2 className="w-3.5 h-3.5 text-[#D53F8C]" />
                      <span className="hidden sm:inline">Share</span>
                    </button>

                    {shareToastPostId === post.id && (
                      <div className="absolute right-0 bottom-full mb-1 px-2.5 py-1 bg-[#D53F8C] text-white text-[10px] font-bold rounded shadow-lg whitespace-nowrap">
                        Memory link copied!
                      </div>
                    )}
                  </div>
                </div>

                {/* Inline Comment Section */}
                {isCommentsOpen && (
                  <div className="mt-4 pt-4 border-t-2 border-teal-100 space-y-3">
                    
                    {/* Add Comment Form */}
                    <form
                      onSubmit={(e) => handleCommentSubmit(post.id, e)}
                      className="flex items-center gap-2"
                    >
                      <img
                        src={currentUser.avatar_url}
                        alt={currentUser.username}
                        className="w-7 h-7 rounded-full object-cover ring-2 ring-[#319795]"
                      />
                      <input
                        type="text"
                        placeholder="Add a comment... (e.g. 'I remember this so well!')"
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        className="flex-1 bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                      />
                      <button
                        type="submit"
                        disabled={!commentInput.trim()}
                        className="p-1.5 bg-[#319795] hover:bg-teal-700 text-white rounded-lg font-bold shadow-[2px_2px_0px_0px_#D53F8C] disabled:opacity-50 transition-all"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </form>

                    {/* Existing Comments List */}
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {post.comments.length === 0 ? (
                        <div className="text-center py-3 text-xs text-slate-500 font-mono">
                          No comments yet. Be the first to reply!
                        </div>
                      ) : (
                        post.comments.map((comment) => (
                          <div
                            key={comment.id}
                            className="p-2.5 bg-[#F0FFF4] rounded-lg border border-[#319795] flex items-start gap-2.5 text-xs"
                          >
                            <img
                              src={comment.author.avatar_url}
                              alt={comment.author.username}
                              className="w-6 h-6 rounded-full object-cover ring-1 ring-[#D53F8C] mt-0.5"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-[#319795]">{comment.author.username}</span>
                                <span className="text-[10px] text-slate-500 font-mono">{formatRelativeTime(comment.created_at)}</span>
                              </div>
                              <p className="text-slate-800 mt-0.5 font-medium">{comment.content}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                  </div>
                )}

              </article>
            );
          })}
        </div>
      )}

    </div>
  );
};
