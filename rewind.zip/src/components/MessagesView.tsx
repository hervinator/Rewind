import React, { useState } from 'react';
import { Conversation, Message, Profile } from '../types';
import { MessageSquare, Send, Bell, Circle, Sparkles, UserCheck } from 'lucide-react';
import { playAimLogonSound, playRetroClickSound } from '../utils/audio';

interface MessagesViewProps {
  conversations: Conversation[];
  messages: Record<string, Message[]>;
  currentUser: Profile;
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  onSendMessage: (conversationId: string, content: string) => void;
  onUpdateAwayMessage?: (message: string) => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  conversations,
  messages,
  currentUser,
  activeConversationId,
  setActiveConversationId,
  onSendMessage,
  onUpdateAwayMessage
}) => {
  const [inputContent, setInputContent] = useState('');
  const [awayMsgInput, setAwayMsgInput] = useState(currentUser.aim_away_message || '');
  const [showAwayModal, setShowAwayModal] = useState(false);

  const activeConv = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const activeMessageList = messages[activeConversationId] || [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputContent.trim()) return;

    onSendMessage(activeConversationId, inputContent.trim());
    setInputContent('');
    playAimLogonSound();
  };

  const handleSaveAway = () => {
    if (onUpdateAwayMessage) {
      onUpdateAwayMessage(awayMsgInput);
    }
    setShowAwayModal(false);
    playRetroClickSound();
  };

  return (
    <div className="space-y-4">
      
      {/* AIM / MSN Retro Top Bar */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-4 shadow-[4px_4px_0px_0px_#D53F8C] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#E6FFFA] border border-[#319795] flex items-center justify-center text-[#319795] font-black font-mono">
            AIM
          </div>
          <div>
            <h1 className="text-base font-black text-[#319795] flex items-center gap-2">
              AOL Instant Messenger (AIM Throwback)
            </h1>
            <p className="text-xs text-slate-600 font-mono">
              Status: <span className="text-[#319795] font-bold">Online</span> • Buddy List Active
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setShowAwayModal(true);
            playRetroClickSound();
          }}
          className="px-3 py-1.5 bg-[#319795] hover:bg-teal-700 text-white font-mono text-xs font-bold rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all"
        >
          Set Away Message
        </button>
      </div>

      {/* Main Split Window */}
      <div className="grid grid-cols-1 md:grid-cols-3 bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#319795] h-[540px]">
        
        {/* Left Side: Buddy List */}
        <div className="md:col-span-1 border-r-2 border-[#319795] flex flex-col bg-[#F0FFF4]">
          <div className="p-3 border-b-2 border-teal-100 bg-[#E6FFFA] flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-[#319795] uppercase tracking-wider flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-[#D53F8C]" /> Buddy List
            </span>
            <span className="text-[10px] font-mono text-slate-500 font-bold">
              {conversations.length} Online
            </span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-teal-100">
            {conversations.map((conv) => {
              const isSelected = conv.id === activeConversationId;
              const isOnline = conv.participant.status === 'online';

              return (
                <button
                  key={conv.id}
                  onClick={() => {
                    setActiveConversationId(conv.id);
                    playRetroClickSound();
                  }}
                  className={`w-full p-3 text-left transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-white border-l-4 border-[#D53F8C]'
                      : 'hover:bg-teal-50'
                  }`}
                >
                  <div className="relative">
                    <img
                      src={conv.participant.avatar_url}
                      alt={conv.participant.username}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-[#319795]"
                    />
                    <Circle
                      className={`w-3 h-3 absolute bottom-0 right-0 fill-current ${
                        isOnline ? 'text-emerald-500' : 'text-amber-500'
                      }`}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-900 truncate">
                        {conv.participant.username}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {conv.last_message_time}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 truncate mt-0.5 font-medium">
                      {conv.last_message}
                    </p>

                    {conv.participant.away_message && (
                      <div className="text-[10px] font-mono italic text-[#D53F8C] truncate mt-1">
                        "{conv.participant.away_message}"
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side: Active Chat Window */}
        <div className="md:col-span-2 flex flex-col bg-white justify-between">
          
          {/* Active Conversation Header */}
          {activeConv && (
            <div className="p-3 border-b-2 border-teal-100 bg-[#F0FFF4] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={activeConv.participant.avatar_url}
                  alt={activeConv.participant.username}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-[#D53F8C]"
                />
                <div>
                  <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                    {activeConv.participant.username}
                    <span className="text-[10px] font-mono text-[#319795]">({activeConv.participant.handle})</span>
                  </div>
                  {activeConv.participant.away_message && (
                    <div className="text-[10px] font-mono text-[#D53F8C] truncate">
                      Away: {activeConv.participant.away_message}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#E6FFFA] text-[#319795] border border-[#319795]">
                  AIM Direct Socket Connected
                </span>
              </div>
            </div>
          )}

          {/* Messages Transcript */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50">
            {activeMessageList.length === 0 ? (
              <div className="text-center py-12 text-xs text-slate-500 font-mono">
                Start typing a message to begin instant messaging...
              </div>
            ) : (
              activeMessageList.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${msg.is_me ? 'justify-end' : 'justify-start'}`}
                >
                  {!msg.is_me && (
                    <img
                      src={msg.sender_avatar}
                      alt={msg.sender_name}
                      className="w-6 h-6 rounded-full object-cover ring-2 ring-[#319795]"
                    />
                  )}

                  <div
                    className={`max-w-[75%] p-3 rounded-xl text-xs space-y-1 shadow-sm ${
                      msg.is_me
                        ? 'bg-[#319795] text-white font-medium rounded-br-none shadow-[2px_2px_0px_0px_#D53F8C]'
                        : 'bg-white border-2 border-[#319795] text-slate-800 rounded-bl-none shadow-[2px_2px_0px_0px_#319795]'
                    }`}
                  >
                    <div className="text-[10px] font-mono font-bold opacity-90 flex items-center justify-between gap-4">
                      <span>{msg.sender_name}</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <p className="leading-relaxed whitespace-pre-line">{msg.content}</p>
                  </div>

                  {msg.is_me && (
                    <img
                      src={currentUser.avatar_url}
                      alt="Me"
                      className="w-6 h-6 rounded-full object-cover ring-2 ring-[#D53F8C]"
                    />
                  )}
                </div>
              ))
            )}
          </div>

          {/* Message Input Form */}
          <form
            onSubmit={handleSend}
            className="p-3 border-t-2 border-[#319795] bg-[#F0FFF4] flex items-center gap-2"
          >
            <input
              type="text"
              placeholder={`Send instant message to ${activeConv?.participant.username || 'buddy'}...`}
              value={inputContent}
              onChange={(e) => setInputContent(e.target.value)}
              className="flex-1 bg-white border-2 border-[#319795] rounded-lg px-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
            />
            <button
              type="submit"
              disabled={!inputContent.trim()}
              className="px-4 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] disabled:opacity-50 transition-all flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>

        </div>
      </div>

      {/* Away Message Modal */}
      {showAwayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-md p-5 shadow-[6px_6px_0px_0px_#D53F8C] space-y-4">
            <div className="flex items-center justify-between border-b-2 border-teal-100 pb-2">
              <span className="font-black text-sm text-[#319795] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#D53F8C]" /> Edit AIM Away Message
              </span>
              <button onClick={() => setShowAwayModal(false)} className="text-xs text-slate-400 hover:text-[#D53F8C]">
                ✕
              </button>
            </div>

            <div>
              <label className="block text-xs text-[#319795] mb-1 font-mono font-bold">
                Cryptic Lyric or Away Status:
              </label>
              <input
                type="text"
                value={awayMsgInput}
                onChange={(e) => setAwayMsgInput(e.target.value)}
                placeholder="~* Out at the arcade bar. Leave a message *~"
                className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] font-mono"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAwayModal(false)}
                className="px-3 py-1.5 text-xs text-slate-500 font-bold hover:text-[#D53F8C]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveAway}
                className="px-4 py-1.5 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
              >
                Save Away Status
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
