import React, { useState } from 'react';
import { Lock, Unlock, Sparkles, Plus, Clock, Calendar, Heart, ShieldAlert, Archive, CheckCircle2, UserCheck } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';
import { TimeCapsuleItem } from '../types';

interface TimeCapsuleViewProps {
  timeCapsuleItems: TimeCapsuleItem[];
  onAddTimeCapsuleItem: (item: Omit<TimeCapsuleItem, 'id' | 'is_locked' | 'created_at'>) => void;
}

export const TimeCapsuleView: React.FC<TimeCapsuleViewProps> = ({
  timeCapsuleItems,
  onAddTimeCapsuleItem
}) => {
  const [isLockModalOpen, setIsLockModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'locked' | 'unlocked' | 'all'>('all');

  // Form State
  const [title, setTitle] = useState('');
  const [memoryText, setMemoryText] = useState('');
  const [unlockDate, setUnlockDate] = useState('2028-12-31');
  const [eraTag, setEraTag] = useState<'90s Kid' | 'Y2K Teen'>('Y2K Teen');

  const filteredItems = timeCapsuleItems.filter((item) => {
    if (activeTab === 'locked') return item.is_locked;
    if (activeTab === 'unlocked') return !item.is_locked;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !memoryText) return;

    onAddTimeCapsuleItem({
      title,
      memory_text: memoryText,
      unlock_date: unlockDate,
      era_tag: eraTag
    });

    playRetroClickSound();
    setIsLockModalOpen(false);
    setTitle('');
    setMemoryText('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <Archive className="w-3.5 h-3.5 text-[#D53F8C]" /> Digital Vault & Memory Crypt
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            Nostalgic Time Capsule Locker 📼
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            Seal private letters, nostalgia predictions, tracklists, and childhood memories into encrypted digital vaults that automatically unlock on chosen future dates!
          </p>
        </div>

        <button
          onClick={() => {
            setIsLockModalOpen(true);
            playRetroClickSound();
          }}
          className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#D53F8C] hover:bg-pink-700 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#319795] transition-all transform hover:-translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          <span>Lock New Capsule</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b-2 border-teal-100 pb-2">
        <button
          onClick={() => {
            setActiveTab('all');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'all'
              ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          All Capsules ({timeCapsuleItems.length})
        </button>

        <button
          onClick={() => {
            setActiveTab('locked');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeTab === 'locked'
              ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Locked Vaults ({timeCapsuleItems.filter((i) => i.is_locked).length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('unlocked');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeTab === 'unlocked'
              ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          <Unlock className="w-3.5 h-3.5" />
          <span>Unlocked Memories ({timeCapsuleItems.filter((i) => !i.is_locked).length})</span>
        </button>
      </div>

      {/* Time Capsule Vault Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredItems.length === 0 ? (
          <div className="md:col-span-2 text-center py-12 px-4 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795]">
            <Lock className="w-10 h-10 text-[#D53F8C] mx-auto mb-3 animate-pulse" />
            <h3 className="text-slate-900 font-black text-lg">No time capsules found</h3>
            <p className="text-slate-600 text-xs mt-1">Create your first digital time capsule to preserve memories for the future!</p>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className={`bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#319795] flex flex-col justify-between space-y-4 relative overflow-hidden transition-all ${
                item.is_locked ? 'hover:border-[#D53F8C]' : ''
              }`}
            >
              <div>
                <div className="flex items-center justify-between border-b-2 border-teal-100 pb-3">
                  <div className="flex items-center gap-2">
                    {item.is_locked ? (
                      <span className="p-2 rounded-lg bg-pink-100 text-[#D53F8C] border border-[#D53F8C]">
                        <Lock className="w-5 h-5" />
                      </span>
                    ) : (
                      <span className="p-2 rounded-lg bg-[#E6FFFA] text-[#319795] border border-[#319795]">
                        <Unlock className="w-5 h-5" />
                      </span>
                    )}

                    <div>
                      <h3 className="font-black text-slate-900 text-base leading-snug">{item.title}</h3>
                      <div className="text-[10px] font-mono text-[#319795] font-bold">
                        Tag: {item.era_tag}
                      </div>
                    </div>
                  </div>

                  <span className="px-2.5 py-1 rounded text-xs font-mono font-bold bg-[#E6FFFA] text-[#319795] border border-[#319795]">
                    Unlock: {item.unlock_date}
                  </span>
                </div>

                <div className="mt-4">
                  {item.is_locked ? (
                    <div className="p-4 bg-[#F0FFF4] rounded-lg border-2 border-dashed border-[#D53F8C] text-center space-y-2">
                      <Clock className="w-6 h-6 text-[#D53F8C] mx-auto animate-pulse" />
                      <div className="text-xs font-black text-[#319795]">Digital Time Capsule Vault Sealed</div>
                      <p className="text-[11px] text-slate-600 italic">
                        The contents of this capsule are locked away until <strong className="text-slate-900">{item.unlock_date}</strong>. Check back on the unlock date!
                      </p>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-800 leading-relaxed bg-[#F0FFF4] p-3 rounded-lg border border-[#319795] font-medium">
                      "{item.memory_text}"
                    </p>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t-2 border-teal-100 flex items-center justify-between text-xs text-slate-600 font-mono">
                <span className="flex items-center gap-1 font-bold">
                  <Calendar className="w-3.5 h-3.5 text-[#319795]" />
                  <span>Created: {new Date(item.created_at).toLocaleDateString()}</span>
                </span>

                <span className={`font-bold ${item.is_locked ? 'text-[#D53F8C]' : 'text-emerald-600'}`}>
                  {item.is_locked ? '🔒 SEALED' : '🔓 UNLOCKED'}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Lock Memory Modal */}
      {isLockModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-md p-6 shadow-[6px_6px_0px_0px_#D53F8C] space-y-4">
            <div className="flex items-center justify-between border-b-2 border-teal-100 pb-2">
              <h3 className="font-black text-[#319795] text-base flex items-center gap-1.5">
                <Lock className="w-5 h-5 text-[#D53F8C]" /> Lock Digital Time Capsule
              </h3>
              <button
                onClick={() => setIsLockModalOpen(false)}
                className="text-slate-400 hover:text-[#D53F8C] font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Capsule Title</label>
                <input
                  type="text"
                  placeholder="e.g. My Favorite 2026 Nostalgia Predictions"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Secret Memory / Letter to Future Self</label>
                <textarea
                  rows={4}
                  placeholder="Write down memories, songs you love right now, life goals, or predictions to open in the future..."
                  value={memoryText}
                  onChange={(e) => setMemoryText(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Unlock Date</label>
                  <input
                    type="date"
                    value={unlockDate}
                    onChange={(e) => setUnlockDate(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Era Tag</label>
                  <select
                    value={eraTag}
                    onChange={(e) => setEraTag(e.target.value as '90s Kid' | 'Y2K Teen')}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="90s Kid">90s Kid</option>
                    <option value="Y2K Teen">Y2K Teen</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsLockModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#D53F8C] hover:bg-pink-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#319795]"
                >
                  Seal & Lock Capsule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
