import React, { useState } from 'react';
import { Community, Profile } from '../types';
import { Users, Plus, Check, Sparkles, Tag, Gamepad2, Tv, MessageSquareText, Disc, X, Send } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';

interface CommunitiesViewProps {
  communities: Community[];
  currentUser: Profile;
  onToggleJoin: (communityId: string) => void;
  onCreateCommunity: (communityData: Omit<Community, 'id' | 'member_count' | 'user_is_member' | 'created_at'>) => void;
  searchQuery?: string;
}

export const CommunitiesView: React.FC<CommunitiesViewProps> = ({
  communities,
  currentUser: _currentUser,
  onToggleJoin,
  onCreateCommunity,
  searchQuery = ''
}) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Gaming');
  const [coverImage, setCoverImage] = useState('');
  const [tagsInput, setTagsInput] = useState('90s, Nostalgia, Retro');

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'Gamepad2': return <Gamepad2 className="w-5 h-5 text-teal-400" />;
      case 'Tv': return <Tv className="w-5 h-5 text-purple-400" />;
      case 'MessageSquareText': return <MessageSquareText className="w-5 h-5 text-emerald-400" />;
      case 'Disc': return <Disc className="w-5 h-5 text-rose-400" />;
      default: return <Users className="w-5 h-5 text-teal-400" />;
    }
  };

  const filteredCommunities = communities.filter((comm) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        comm.name.toLowerCase().includes(q) ||
        comm.description.toLowerCase().includes(q) ||
        comm.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onCreateCommunity({
      name: name.trim(),
      description: description.trim(),
      category,
      icon: 'Users',
      cover_image: coverImage.trim() || 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
      tags: tagsInput.split(',').map(t => t.trim()).filter(Boolean)
    });

    playRetroClickSound();
    setIsCreateModalOpen(false);
    setName('');
    setDescription('');
    setCoverImage('');
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <Users className="w-3.5 h-3.5 text-[#D53F8C]" /> Retro Interest Circles
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            Nostalgia Communities
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            Join niche sub-communities dedicated to your favorite 90s cartoons, retro consoles, AIM away messages, and cassette mixtapes!
          </p>
        </div>

        <button
          onClick={() => {
            setIsCreateModalOpen(true);
            playRetroClickSound();
          }}
          className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#319795] hover:bg-teal-700 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all transform hover:-translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          <span>Create Community</span>
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredCommunities.map((comm) => (
          <div
            key={comm.id}
            className="bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#319795] flex flex-col justify-between transition-all group"
          >
            <div>
              {/* Cover */}
              <div className="relative h-36 overflow-hidden bg-slate-100 border-b-2 border-[#319795]">
                <img
                  src={comm.cover_image}
                  alt={comm.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />

                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-white border-2 border-[#319795] shadow-sm">
                    {getIconComponent(comm.icon)}
                  </div>
                  <span className="px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-full bg-white border-2 border-[#319795] text-[#319795]">
                    {comm.category}
                  </span>
                </div>
              </div>

              {/* Info */}
              <div className="p-5 space-y-3">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-black text-slate-900">
                    {comm.name}
                  </h3>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {comm.description}
                </p>

                {/* Tags & Members */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t-2 border-teal-100 text-xs">
                  <div className="flex flex-wrap gap-1">
                    {comm.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-[#F0FFF4] text-[#319795] border border-[#319795] flex items-center gap-1"
                      >
                        <Tag className="w-2.5 h-2.5 text-[#D53F8C]" /> {tag}
                      </span>
                    ))}
                  </div>

                  <span className="text-xs font-mono font-bold text-[#319795]">
                    {comm.member_count.toLocaleString()} members
                  </span>
                </div>
              </div>
            </div>

            {/* Join Toggle Button */}
            <div className="p-4 bg-[#F0FFF4] border-t-2 border-teal-100">
              <button
                onClick={() => {
                  onToggleJoin(comm.id);
                  playRetroClickSound();
                }}
                className={`w-full py-2.5 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                  comm.user_is_member
                    ? 'bg-white border-2 border-[#319795] text-[#319795] shadow-sm'
                    : 'bg-[#319795] hover:bg-teal-700 text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                }`}
              >
                {comm.user_is_member ? (
                  <>
                    <Check className="w-4 h-4 text-[#D53F8C]" />
                    <span>Member (Click to Leave)</span>
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4" />
                    <span>Join Community</span>
                  </>
                )}
              </button>
            </div>

          </div>
        ))}
      </div>

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-md shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#D53F8C]" />
                <h2 className="text-lg font-black text-[#319795]">Create Retro Circle</h2>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 text-slate-400 hover:text-[#D53F8C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Community Name</label>
                <input
                  type="text"
                  placeholder="e.g. 90s Toonami Anime Club"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="What is this community about?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="Gaming">Gaming</option>
                    <option value="Movies & TV">Movies & TV</option>
                    <option value="Nostalgia">Nostalgia</option>
                    <option value="Music">Music</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Tags (Comma Separated)</label>
                  <input
                    type="text"
                    value={tagsInput}
                    onChange={(e) => setTagsInput(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Cover Image URL</label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/..."
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Launch Circle</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
