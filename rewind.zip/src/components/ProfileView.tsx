import React, { useState } from 'react';
import { Profile, Post, EraPreference, TimeCapsuleItem } from '../types';
import { User, Edit3, Award, Lock, Unlock, Sparkles, Heart, MessageSquare, Plus, Calendar, MapPin, Check, Save } from 'lucide-react';
import { formatRelativeTime } from '../utils/dateFormatter';
import { playRetroClickSound } from '../utils/audio';

interface ProfileViewProps {
  currentUser: Profile;
  userPosts: Post[];
  timeCapsuleItems: TimeCapsuleItem[];
  onUpdateProfile: (updatedProfile: Partial<Profile>) => void;
  onAddTimeCapsuleItem: (item: Omit<TimeCapsuleItem, 'id' | 'is_locked' | 'created_at'>) => void;
  onLikePost: (postId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  userPosts,
  timeCapsuleItems,
  onUpdateProfile,
  onAddTimeCapsuleItem,
  onLikePost
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'memories' | 'capsule' | 'media'>('memories');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isLockModalOpen, setIsLockModalOpen] = useState(false);

  // Profile Edit State
  const [username, setUsername] = useState(currentUser.username);
  const [handle, setHandle] = useState(currentUser.handle);
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatar_url);
  const [eraPref, setEraPref] = useState<EraPreference>(currentUser.era_preference);
  const [bio, setBio] = useState(currentUser.bio);
  const [location, setLocation] = useState(currentUser.location);
  const [favShow, setFavShow] = useState(currentUser.favorite_childhood_media.favorite_show);
  const [favGame, setFavGame] = useState(currentUser.favorite_childhood_media.favorite_game);
  const [favSnack, setFavSnack] = useState(currentUser.favorite_childhood_media.favorite_snack);

  // Time Capsule Lock State
  const [capsuleTitle, setCapsuleTitle] = useState('');
  const [capsuleMemory, setCapsuleMemory] = useState('');
  const [unlockYear, setUnlockYear] = useState('2028-01-01');

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      username,
      handle,
      avatar_url: avatarUrl,
      era_preference: eraPref,
      bio,
      location,
      favorite_childhood_media: {
        favorite_show: favShow,
        favorite_game: favGame,
        favorite_snack: favSnack,
        favorite_album: currentUser.favorite_childhood_media.favorite_album
      }
    });

    playRetroClickSound();
    setIsEditModalOpen(false);
  };

  const handleCapsuleLockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!capsuleTitle.trim() || !capsuleMemory.trim()) return;

    onAddTimeCapsuleItem({
      title: capsuleTitle.trim(),
      memory_text: capsuleMemory.trim(),
      unlock_date: unlockYear
    });

    playRetroClickSound();
    setIsLockModalOpen(false);
    setCapsuleTitle('');
    setCapsuleMemory('');
  };

  return (
    <div className="space-y-6">
      
      {/* Profile Card Header */}
      <div className="bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#319795] relative">
        
        {/* Banner */}
        <div className="h-44 sm:h-52 w-full relative bg-slate-100 border-b-2 border-[#319795]">
          <img
            src={currentUser.banner_url || 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80'}
            alt="Profile Banner"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />
        </div>

        {/* Profile Details Bar */}
        <div className="p-6 pt-0 relative z-10 -mt-16 sm:-mt-20">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
            
            <div className="flex items-end gap-4">
              <img
                src={currentUser.avatar_url}
                alt={currentUser.username}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl object-cover ring-4 ring-white border-2 border-[#319795] shadow-[2px_2px_0px_0px_#D53F8C]"
              />
              <div className="mb-1 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 drop-shadow-sm">
                    {currentUser.username}
                  </h1>
                  <span className="px-2.5 py-0.5 text-xs font-mono font-bold rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795]">
                    {currentUser.era_preference}
                  </span>
                </div>
                <div className="text-xs text-slate-600 font-mono font-bold">
                  {currentUser.handle} • <span className="text-[#319795]">{currentUser.location}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setIsEditModalOpen(true);
                playRetroClickSound();
              }}
              className="flex items-center gap-2 px-4 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all"
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E6FFFA]" />
              <span>Edit Time Capsule Profile</span>
            </button>

          </div>

          {/* Bio */}
          <p className="mt-4 text-xs sm:text-sm text-slate-700 leading-relaxed max-w-3xl font-medium">
            {currentUser.bio}
          </p>

          {/* Badges Stack */}
          <div className="mt-4 pt-4 border-t-2 border-teal-100 flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono font-bold text-[#319795] uppercase tracking-wider flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-[#D53F8C]" /> Earned Badges:
            </span>
            {currentUser.badges.map((badge, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 text-[11px] font-mono font-bold rounded-lg bg-[#F0FFF4] border border-[#319795] text-[#319795] flex items-center gap-1 shadow-[1px_1px_0px_0px_#D53F8C]"
              >
                🏆 {badge}
              </span>
            ))}
          </div>

        </div>

      </div>

      {/* Sub Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b-2 border-teal-100 pb-2">
        <button
          onClick={() => {
            setActiveSubTab('memories');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
            activeSubTab === 'memories'
              ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>My Posted Memories ({userPosts.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('capsule');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
            activeSubTab === 'capsule'
              ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Digital Time Capsule ({timeCapsuleItems.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveSubTab('media');
            playRetroClickSound();
          }}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
            activeSubTab === 'media'
              ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
              : 'bg-white border-2 border-[#319795] text-[#319795] hover:bg-teal-50'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Favorite Childhood Media</span>
        </button>
      </div>

      {/* Tab Content: My Posted Memories */}
      {activeSubTab === 'memories' && (
        <div className="space-y-4">
          {userPosts.length === 0 ? (
            <div className="text-center py-12 px-4 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795]">
              <Sparkles className="w-8 h-8 text-[#D53F8C] mx-auto mb-2" />
              <h3 className="text-slate-900 font-bold text-base">You haven't posted any memories yet</h3>
              <p className="text-slate-600 text-xs mt-1">Share your first memory to populate your time capsule!</p>
            </div>
          ) : (
            userPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#319795] space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.author.avatar_url}
                      alt={post.author.username}
                      className="w-9 h-9 rounded-full object-cover ring-2 ring-[#D53F8C]"
                    />
                    <div>
                      <div className="font-bold text-xs text-slate-900">{post.author.username}</div>
                      <div className="text-[10px] text-slate-500 font-mono font-bold">{formatRelativeTime(post.created_at)}</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-white border-2 border-[#319795] text-[#319795]">
                    {post.decade_tag}
                  </span>
                </div>

                <p className="text-slate-800 text-xs leading-relaxed font-medium">{post.content}</p>

                {post.image_url && (
                  <div className="rounded-lg overflow-hidden max-h-72 bg-slate-100 border-2 border-[#319795]">
                    <img src={post.image_url} alt="Memory" className="w-full h-full object-cover" />
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t-2 border-teal-100 text-xs text-slate-600">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className="flex items-center gap-1 text-slate-600 hover:text-[#D53F8C] font-bold"
                    >
                      <Heart className={`w-4 h-4 ${post.user_liked ? 'fill-[#D53F8C] text-[#D53F8C]' : ''}`} />
                      <span>{post.likes_count}</span>
                    </button>
                    <span className="flex items-center gap-1 font-bold">
                      <MessageSquare className="w-4 h-4 text-[#319795]" />
                      <span>{post.comments_count}</span>
                    </span>
                  </div>
                  <span className="font-mono text-[10px] font-bold text-[#319795]">{post.category}</span>
                </div>
              </article>
            ))
          )}
        </div>
      )}

      {/* Tab Content: Digital Time Capsule */}
      {activeSubTab === 'capsule' && (
        <div className="space-y-4">
          
          <div className="bg-[#F0FFF4] border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-black text-[#319795] text-base flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#D53F8C]" /> Digital Time Capsule Locker
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Lock personal memories to unlock on a specified future date in time!
              </p>
            </div>
            <button
              onClick={() => {
                setIsLockModalOpen(true);
                playRetroClickSound();
              }}
              className="px-4 py-2 bg-[#D53F8C] hover:bg-pink-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#319795] transition-all flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Lock New Memory</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {timeCapsuleItems.map((item) => (
              <div
                key={item.id}
                className={`p-5 rounded-xl border-2 border-[#319795] transition-all shadow-[4px_4px_0px_0px_#319795] space-y-3 ${
                  item.is_locked
                    ? 'bg-white relative overflow-hidden'
                    : 'bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    {item.is_locked ? (
                      <Lock className="w-4 h-4 text-[#D53F8C]" />
                    ) : (
                      <Unlock className="w-4 h-4 text-[#319795]" />
                    )}
                    <span>{item.title}</span>
                  </h4>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#E6FFFA] text-[#319795] border border-[#319795]">
                    Unlock: {item.unlock_date}
                  </span>
                </div>

                {item.is_locked ? (
                  <div className="p-4 bg-[#E6FFFA] rounded-lg border border-[#319795] text-center space-y-2">
                    <Lock className="w-6 h-6 text-[#D53F8C] mx-auto animate-pulse" />
                    <div className="text-xs font-bold text-[#319795]">Memory Capsule Locked</div>
                    <p className="text-[11px] text-slate-600 italic">
                      This digital time capsule will automatically unlock on {item.unlock_date}.
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-800 leading-relaxed bg-[#F0FFF4] p-3 rounded-lg border border-[#319795] font-medium">
                    {item.memory_text}
                  </p>
                )}
              </div>
            ))}
          </div>

        </div>
      )}

      {/* Tab Content: Favorite Childhood Media */}
      {activeSubTab === 'media' && (
        <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#319795] space-y-4">
          <h3 className="font-black text-[#319795] text-base border-b-2 border-teal-100 pb-3 flex items-center gap-2">
            <Award className="w-4 h-4 text-[#D53F8C]" /> Childhood Favorites Showcase
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] space-y-1">
              <div className="text-[10px] font-mono uppercase text-[#319795] font-bold">Favorite Childhood Show</div>
              <div className="text-slate-900 font-black text-sm">{currentUser.favorite_childhood_media.favorite_show}</div>
            </div>

            <div className="p-4 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] space-y-1">
              <div className="text-[10px] font-mono uppercase text-[#319795] font-bold">Favorite Video Game</div>
              <div className="text-slate-900 font-black text-sm">{currentUser.favorite_childhood_media.favorite_game}</div>
            </div>

            <div className="p-4 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] space-y-1">
              <div className="text-[10px] font-mono uppercase text-[#319795] font-bold">Favorite After-School Snack</div>
              <div className="text-slate-900 font-black text-sm">{currentUser.favorite_childhood_media.favorite_snack}</div>
            </div>

            <div className="p-4 bg-[#F0FFF4] rounded-lg border-2 border-[#319795] space-y-1">
              <div className="text-[10px] font-mono uppercase text-[#319795] font-bold">Favorite High School Album</div>
              <div className="text-slate-900 font-black text-sm">{currentUser.favorite_childhood_media.favorite_album}</div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-lg shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
              <h2 className="text-lg font-black text-[#319795]">Edit Profile & Era Preference</h2>
              <button onClick={() => setIsEditModalOpen(false)} className="text-slate-400 hover:text-[#D53F8C]">✕</button>
            </div>

            <form onSubmit={handleProfileSave} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Display Name</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Childhood Era Preference</label>
                <select
                  value={eraPref}
                  onChange={(e) => setEraPref(e.target.value as EraPreference)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                >
                  <option value="90s Kid">90s Kid</option>
                  <option value="Y2K Teen">Y2K Teen</option>
                  <option value="Late 90s / Early 00s Hybrid">Late 90s / Early 00s Hybrid</option>
                  <option value="Retro Enthusiast">Retro Enthusiast</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Avatar Image URL</label>
                <input
                  type="url"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Bio & AIM Away Message</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-[#319795] mb-1">Favorite Show</label>
                  <input
                    type="text"
                    value={favShow}
                    onChange={(e) => setFavShow(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[#319795] mb-1">Favorite Game</label>
                  <input
                    type="text"
                    value={favGame}
                    onChange={(e) => setFavGame(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[#319795] mb-1">Favorite Snack</label>
                  <input
                    type="text"
                    value={favSnack}
                    onChange={(e) => setFavSnack(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lock Memory Modal */}
      {isLockModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-md p-6 shadow-[6px_6px_0px_0px_#D53F8C] space-y-4">
            <div className="flex items-center justify-between border-b-2 border-teal-100 pb-2">
              <h3 className="font-black text-[#319795] text-sm flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-[#D53F8C]" /> Lock Memory Capsule
              </h3>
              <button onClick={() => setIsLockModalOpen(false)} className="text-slate-400 hover:text-[#D53F8C]">✕</button>
            </div>

            <form onSubmit={handleCapsuleLockSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Capsule Title</label>
                <input
                  type="text"
                  placeholder="e.g. My Favorite 2026 Retro Tracklist"
                  value={capsuleTitle}
                  onChange={(e) => setCapsuleTitle(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Secret Memory Text</label>
                <textarea
                  rows={3}
                  placeholder="Write a private memory or prediction to lock..."
                  value={capsuleMemory}
                  onChange={(e) => setCapsuleMemory(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Unlock Date</label>
                <input
                  type="date"
                  value={unlockYear}
                  onChange={(e) => setUnlockYear(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsLockModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 font-bold hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#D53F8C] hover:bg-pink-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#319795]"
                >
                  Lock Capsule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
