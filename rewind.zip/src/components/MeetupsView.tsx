import React, { useState } from 'react';
import { Meetup, Profile } from '../types';
import { Calendar, MapPin, Users, Plus, Check, Clock, Sparkles, Filter, X, Send } from 'lucide-react';
import { formatMeetupDate } from '../utils/dateFormatter';
import { playRetroClickSound } from '../utils/audio';

interface MeetupsViewProps {
  meetups: Meetup[];
  currentUser: Profile;
  onToggleAttend: (meetupId: string) => void;
  onCreateMeetup: (meetupData: Omit<Meetup, 'id' | 'attendees_count' | 'user_is_attending' | 'attendees_avatars' | 'created_at'>) => void;
  searchQuery?: string;
}

export const MeetupsView: React.FC<MeetupsViewProps> = ({
  meetups,
  currentUser,
  onToggleAttend,
  onCreateMeetup,
  searchQuery = ''
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'attending' | 'gaming' | 'music'>('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Meetup['category']>('Arcade & Gaming');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState('');
  const [coverImage, setCoverImage] = useState('');

  const filteredMeetups = meetups.filter((meetup) => {
    if (filterTab === 'attending' && !meetup.user_is_attending) return false;
    if (filterTab === 'gaming' && meetup.category !== 'Arcade & Gaming') return false;
    if (filterTab === 'music' && meetup.category !== 'Music & Concerts') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        meetup.title.toLowerCase().includes(q) ||
        meetup.description.toLowerCase().includes(q) ||
        meetup.location.toLowerCase().includes(q) ||
        meetup.city.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date || !location.trim()) return;

    onCreateMeetup({
      title: title.trim(),
      description: description.trim(),
      category,
      date,
      time: time || '7:00 PM',
      location: location.trim(),
      city: city.trim() || 'Austin, TX',
      organizer: {
        id: currentUser.id,
        username: currentUser.username,
        avatar_url: currentUser.avatar_url,
        handle: currentUser.handle
      },
      max_attendees: 50,
      cover_image: coverImage.trim() || 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80'
    });

    playRetroClickSound();
    setIsCreateModalOpen(false);
    // Reset
    setTitle('');
    setDescription('');
    setDate('');
    setTime('');
    setLocation('');
    setCity('');
    setCoverImage('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <Calendar className="w-3.5 h-3.5 text-[#D53F8C]" /> Real-World Hangouts
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            Nostalgic Local Meetups & Hangouts
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            Connect with fellow 90s & 2000s kids for arcade bar nights, N64 multiplayer tournaments, 2000s emo karaoke, and cereal bar watch parties!
          </p>
        </div>

        <button
          onClick={() => {
            setIsCreateModalOpen(true);
            playRetroClickSound();
          }}
          className="shrink-0 flex items-center gap-2 px-5 py-3 bg-[#319795] hover:bg-teal-700 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all transform hover:-translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          <span>Host a Meetup</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border-2 border-[#319795] rounded-xl p-3 shadow-[2px_2px_0px_0px_#319795]">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#D53F8C] ml-1" />
          <div className="flex items-center gap-1.5 bg-[#F0FFF4] p-1 rounded-lg border border-[#319795]">
            {[
              { id: 'all', label: 'All Meetups' },
              { id: 'attending', label: "I'm Going" },
              { id: 'gaming', label: 'Arcade & Gaming' },
              { id: 'music', label: 'Music & Concerts' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setFilterTab(tab.id as typeof filterTab);
                  playRetroClickSound();
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  filterTab === tab.id
                    ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                    : 'text-[#319795] hover:bg-teal-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <span className="text-xs text-[#319795] font-mono font-bold">
          Showing {filteredMeetups.length} event{filteredMeetups.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Meetups Grid */}
      {filteredMeetups.length === 0 ? (
        <div className="text-center py-12 px-4 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#319795]">
          <Sparkles className="w-8 h-8 text-[#D53F8C] mx-auto mb-2" />
          <h3 className="text-slate-900 font-bold text-base">No meetups found</h3>
          <p className="text-slate-600 text-xs mt-1">Host the first local hangout in your city!</p>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="mt-4 px-4 py-2 bg-[#319795] text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
          >
            Create Event
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredMeetups.map((meetup) => (
            <div
              key={meetup.id}
              className="bg-white border-2 border-[#319795] rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_#319795] flex flex-col justify-between transition-all group"
            >
              <div>
                {/* Cover Image & Category Badge */}
                <div className="relative h-48 overflow-hidden bg-slate-100 border-b-2 border-[#319795]">
                  <img
                    src={meetup.cover_image}
                    alt={meetup.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />

                  <div className="absolute top-3 left-3 flex gap-2">
                    <span className="px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-full bg-white border-2 border-[#319795] text-[#319795]">
                      {meetup.category}
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-lg font-black text-white drop-shadow line-clamp-1">
                      {meetup.title}
                    </h3>
                  </div>
                </div>

                {/* Details Section */}
                <div className="p-4 space-y-3">
                  
                  {/* Clean Formatted Date & Location */}
                  <div className="space-y-1.5 text-xs text-slate-700 font-medium">
                    <div className="flex items-center gap-2 text-[#319795] font-bold">
                      <Clock className="w-4 h-4 text-[#D53F8C] shrink-0" />
                      <span>{formatMeetupDate(meetup.date, meetup.time)}</span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-600">
                      <MapPin className="w-4 h-4 text-[#319795] shrink-0" />
                      <span className="truncate">{meetup.location} ({meetup.city})</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3 font-medium">
                    {meetup.description}
                  </p>

                  {/* Organizer & Attendees Stack */}
                  <div className="pt-2 border-t-2 border-teal-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <img
                        src={meetup.organizer.avatar_url}
                        alt={meetup.organizer.username}
                        className="w-6 h-6 rounded-full object-cover ring-2 ring-[#D53F8C]"
                      />
                      <span className="text-slate-500 text-[11px]">
                        Host: <strong className="text-slate-900 font-bold">{meetup.organizer.username}</strong>
                      </span>
                    </div>

                    {/* Attendee Avatars */}
                    <div className="flex items-center gap-1.5">
                      <div className="flex -space-x-2">
                        {meetup.attendees_avatars.slice(0, 3).map((img, i) => (
                          <img
                            key={i}
                            src={img}
                            alt="Attendee"
                            className="w-6 h-6 rounded-full object-cover ring-2 ring-white"
                          />
                        ))}
                      </div>
                      <span className="text-[11px] font-mono font-bold text-[#319795]">
                        {meetup.attendees_count} going
                      </span>
                    </div>
                  </div>

                </div>
              </div>

              {/* Action Button */}
              <div className="p-4 bg-[#F0FFF4] border-t-2 border-teal-100">
                <button
                  onClick={() => {
                    onToggleAttend(meetup.id);
                    playRetroClickSound();
                  }}
                  className={`w-full py-2.5 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                    meetup.user_is_attending
                      ? 'bg-white border-2 border-[#319795] text-[#319795] shadow-sm'
                      : 'bg-[#319795] hover:bg-teal-700 text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                  }`}
                >
                  {meetup.user_is_attending ? (
                    <>
                      <Check className="w-4 h-4 text-[#D53F8C]" />
                      <span>You are going! (Click to Leave)</span>
                    </>
                  ) : (
                    <>
                      <Users className="w-4 h-4" />
                      <span>I'm Going!</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Host Meetup Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-lg shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#D53F8C]" />
                <h2 className="text-lg font-black text-[#319795]">Host a Nostalgic Meetup</h2>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 text-slate-400 hover:text-[#D53F8C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Meetup Title</label>
                <input
                  type="text"
                  placeholder="e.g. 90s Arcade & Pinball Tournament Night"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="Describe the activity, dress code, pizza/drinks, games provided..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as Meetup['category'])}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  >
                    <option value="Arcade & Gaming">Arcade & Gaming</option>
                    <option value="Music & Concerts">Music & Concerts</option>
                    <option value="Food & Snacks">Food & Snacks</option>
                    <option value="Trivia & Watch Party">Trivia & Watch Party</option>
                    <option value="Swap Meet">Swap Meet</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">City</label>
                  <input
                    type="text"
                    placeholder="e.g. Austin, TX"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Event Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#319795] mb-1">Time</label>
                  <input
                    type="text"
                    placeholder="e.g. 7:00 PM"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Venue / Location Name</label>
                <input
                  type="text"
                  placeholder="e.g. 1UP Retro Arcade Bar"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#319795] mb-1">Cover Image URL (Optional)</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-teal-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Publish Meetup</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
