import React from 'react';
import { Home, Compass, Users, Calendar, MapPin, Music, Archive, ShoppingBag, MessageSquare, User, Sparkles } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadMessagesCount?: number;
  mobileMenuOpen?: boolean;
  setMobileMenuOpen?: (open: boolean) => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  unreadMessagesCount = 1,
  mobileMenuOpen = false,
  setMobileMenuOpen
}) => {
  const navItems = [
    { id: 'feed', label: 'Feed', icon: Home, emoji: '🏠', badge: null },
    { id: 'discover', label: 'Discover', icon: Compass, emoji: '🔥', badge: 'HOT' },
    { id: 'communities', label: 'Communities', icon: Users, emoji: '💬', badge: null },
    { id: 'meetups', label: 'Meetups', icon: Calendar, emoji: '📅', badge: 'NEW' },
    { id: 'memory_map', label: 'Memory Map', icon: MapPin, emoji: '🗺', badge: 'MAP' },
    { id: 'music', label: 'Music', icon: Music, emoji: '🎵', badge: 'WINAMP' },
    { id: 'time_capsule', label: 'Time Capsule', icon: Archive, emoji: '📼', badge: 'VAULT' },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag, emoji: '🏷️', badge: null },
    { id: 'messages', label: 'Messages', icon: MessageSquare, emoji: '💬', badge: unreadMessagesCount > 0 ? unreadMessagesCount : null },
    { id: 'profile', label: 'Profile', icon: User, emoji: '👤', badge: null }
  ];

  const handleSelect = (id: string) => {
    setActiveTab(id);
    playRetroClickSound();
    if (setMobileMenuOpen) {
      setMobileMenuOpen(false);
    }
  };

  return (
    <>
      {/* Desktop Sidebar Navigation */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 space-y-6">
        <div className="bg-white border-2 border-[#319795] rounded-xl p-4 shadow-[4px_4px_0px_0px_#D53F8C] sticky top-20">
          <div className="text-xs font-black uppercase tracking-widest text-[#319795] px-2 mb-3 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#D53F8C]" /> Menu Navigation
          </div>

          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg font-bold text-sm transition-all group ${
                    isActive
                      ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                      : 'text-[#319795] hover:bg-teal-50 hover:text-[#319795] border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                        isActive ? 'text-white' : 'text-[#319795]'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded-full ${
                        isActive
                          ? 'bg-white text-[#D53F8C]'
                          : item.badge === 'HOT'
                          ? 'bg-[#D53F8C] text-white'
                          : 'bg-[#319795] text-white'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Era Card / Quick Tip */}
          <div className="mt-6 pt-4 border-t-2 border-teal-100">
            <div className="p-3 bg-[#F0FFF4] border-2 border-dashed border-[#D53F8C] rounded-xl">
              <div className="text-xs font-bold text-[#319795] flex items-center gap-1.5">
                📟 Retro Pro-Tip
              </div>
              <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                Click the sound toggle in the top header to enable dial-up, AIM door, & MSN nudge retro sound effects!
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Menu Drawer Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen && setMobileMenuOpen(false)}
          />

          <div className="fixed inset-y-0 left-0 w-72 bg-white border-r-2 border-[#319795] p-5 shadow-2xl flex flex-col justify-between overflow-y-auto">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b-2 border-teal-100 pb-3">
                <span className="font-black text-[#319795] italic text-lg">MILLENNIAL <span className="text-[#D53F8C]">MEMORY LANE</span></span>
                <button
                  onClick={() => setMobileMenuOpen && setMobileMenuOpen(false)}
                  className="p-1 text-slate-400 hover:text-[#D53F8C]"
                >
                  ✕
                </button>
              </div>

              <nav className="space-y-1.5">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelect(item.id)}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                        isActive
                          ? 'bg-[#D53F8C] text-white shadow-[2px_2px_0px_0px_#319795]'
                          : 'text-[#319795] hover:bg-teal-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-[#319795]'}`} />
                        <span>{item.label}</span>
                      </div>

                      {item.badge && (
                        <span className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded-full ${isActive ? 'bg-white text-[#D53F8C]' : 'bg-[#319795] text-white'}`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            <div className="pt-4 border-t-2 border-teal-100 text-center text-xs text-[#319795] font-mono font-bold">
              Millennial Memory Lane v1.0
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <div className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-white border-t-2 border-[#319795] px-2 py-1 shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {navItems.slice(0, 5).map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`flex flex-col items-center py-1 px-2 rounded-lg transition-all ${
                  isActive ? 'text-[#D53F8C] font-bold scale-105' : 'text-[#319795] hover:text-[#D53F8C]'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] mt-0.5 font-medium">{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={() => handleSelect('profile')}
            className={`flex flex-col items-center py-1 px-2 rounded-lg transition-all ${
              activeTab === 'profile' ? 'text-[#D53F8C] font-bold scale-105' : 'text-[#319795] hover:text-[#D53F8C]'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 font-medium">Profile</span>
          </button>
        </div>
      </div>
    </>
  );
};
