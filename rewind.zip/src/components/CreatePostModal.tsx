import React, { useState } from 'react';
import { X, Image as ImageIcon, Sparkles, Send, Tag, HelpCircle } from 'lucide-react';
import { PostCategory, DecadeTag, Profile } from '../types';
import { playRetroClickSound } from '../utils/audio';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Profile;
  onSubmit: (postData: {
    content: string;
    image_url?: string;
    category: PostCategory;
    decade_tag: DecadeTag;
  }) => void;
}

const PRESET_NOSTALGIC_IMAGES = [
  { label: 'Tamagotchi Pet', url: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?auto=format&fit=crop&w=800&q=80' },
  { label: 'Game Boy & Retro Games', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80' },
  { label: 'Blockbuster & VHS', url: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80' },
  { label: 'AIM & Cyber Screen', url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80' },
  { label: 'Retro Arcade Machines', url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80' },
  { label: 'Cassettes & iPod', url: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80' }
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSubmit
}) => {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [category, setCategory] = useState<PostCategory>('Nostalgia');
  const [decadeTag, setDecadeTag] = useState<DecadeTag>('90s');
  const [showPresets, setShowPresets] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onSubmit({
      content: content.trim(),
      image_url: imageUrl.trim() || undefined,
      category,
      decade_tag: decadeTag
    });

    playRetroClickSound();
    setContent('');
    setImageUrl('');
    onClose();
  };

  const handlePromptClick = (promptText: string) => {
    setContent(promptText);
    playRetroClickSound();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white border-2 border-[#319795] rounded-xl w-full max-w-xl shadow-[6px_6px_0px_0px_#D53F8C] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 border-b-2 border-teal-100 flex items-center justify-between bg-[#F0FFF4]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#D53F8C]" />
            <h2 className="text-lg font-black text-[#319795]">Share a Childhood Memory</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-[#D53F8C] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          
          {/* User Info Header */}
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar_url}
              alt={currentUser.username}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-[#D53F8C]"
            />
            <div>
              <div className="font-bold text-sm text-slate-900">{currentUser.username}</div>
              <div className="text-xs text-[#319795] font-mono font-bold">{currentUser.era_preference}</div>
            </div>
          </div>

          {/* Quick Prompts */}
          <div className="p-3 bg-[#F0FFF4] border-2 border-dashed border-[#319795] rounded-lg">
            <div className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#319795] mb-2 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-[#D53F8C]" /> Need inspiration? Click a prompt:
            </div>
            <div className="flex flex-wrap gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => handlePromptClick('Who remembers Blockbuster Friday nights? Renting a movie & SNES cartridge...')}
                className="px-2.5 py-1 bg-white hover:bg-[#E6FFFA] border border-[#319795] text-[#319795] font-bold rounded-lg transition-all text-left shadow-sm"
              >
                📼 Blockbuster Friday nights
              </button>
              <button
                type="button"
                onClick={() => handlePromptClick('The sheer panic of feeding your Tamagotchi in class before it died...')}
                className="px-2.5 py-1 bg-white hover:bg-[#E6FFFA] border border-[#319795] text-[#319795] font-bold rounded-lg transition-all text-left shadow-sm"
              >
                🥚 Tamagotchi panic
              </button>
              <button
                type="button"
                onClick={() => handlePromptClick('What was your go-to AIM away message when your crush was online?')}
                className="px-2.5 py-1 bg-white hover:bg-[#E6FFFA] border border-[#319795] text-[#319795] font-bold rounded-lg transition-all text-left shadow-sm"
              >
                💬 AIM Away Messages
              </button>
            </div>
          </div>

          {/* Main Textarea */}
          <textarea
            rows={4}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Tell your nostalgic story... (e.g., 'Who remembers blowing into N64 cartridges or setting AIM away messages?')"
            className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-3.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] transition-all resize-none font-medium"
            required
          />

          {/* Tags & Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#319795] mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-[#D53F8C]" /> Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PostCategory)}
                className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg p-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
              >
                <option value="Nostalgia">Nostalgia</option>
                <option value="Tech & Toys">Tech & Toys</option>
                <option value="Movies & TV">Movies & TV</option>
                <option value="Gaming">Gaming</option>
                <option value="Music">Music</option>
                <option value="Snacks & Food">Snacks & Food</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#319795] mb-1">
                Decade Era Tag
              </label>
              <div className="flex rounded-lg bg-[#F0FFF4] border-2 border-[#319795] p-1">
                {(['90s', '2000s', 'Both'] as DecadeTag[]).map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setDecadeTag(tag);
                      playRetroClickSound();
                    }}
                    className={`flex-1 py-1 text-xs font-bold rounded transition-all ${
                      decadeTag === tag
                        ? 'bg-[#319795] text-white shadow-[2px_2px_0px_0px_#D53F8C]'
                        : 'text-[#319795] hover:bg-teal-50'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Image Upload / Preset Section */}
          <div className="space-y-2 pt-2 border-t-2 border-teal-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-[#319795] flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-[#D53F8C]" /> Add Memory Photo (URL or Preset)
              </label>
              <button
                type="button"
                onClick={() => setShowPresets(!showPresets)}
                className="text-xs text-[#D53F8C] hover:underline font-bold"
              >
                {showPresets ? 'Hide Presets' : 'Choose Retro Preset Photo'}
              </button>
            </div>

            <input
              type="url"
              placeholder="Paste image URL (e.g. https://...)"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
            />

            {showPresets && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                {PRESET_NOSTALGIC_IMAGES.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setImageUrl(preset.url);
                      playRetroClickSound();
                    }}
                    className={`relative group rounded-lg overflow-hidden border-2 transition-all h-16 ${
                      imageUrl === preset.url ? 'border-[#D53F8C] ring-2 ring-[#D53F8C]' : 'border-[#319795]'
                    }`}
                  >
                    <img src={preset.url} alt={preset.label} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <span className="absolute inset-x-0 bottom-0 bg-white/90 text-[10px] text-[#319795] p-0.5 text-center truncate font-bold">
                      {preset.label}
                    </span>
                  </button>
                ))}
              </div>
            )}

            {imageUrl && (
              <div className="relative mt-2 rounded-lg overflow-hidden border-2 border-[#319795] max-h-40 bg-[#F0FFF4] flex items-center justify-center">
                <img src={imageUrl} alt="Memory preview" className="max-h-40 w-full object-cover" />
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="absolute top-2 right-2 p-1 bg-[#D53F8C] text-white rounded-full hover:bg-rose-700"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-teal-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-[#D53F8C] rounded-lg hover:bg-teal-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!content.trim()}
              className="flex items-center gap-2 px-5 py-2 bg-[#319795] hover:bg-teal-700 text-white font-bold text-xs rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post Memory</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
