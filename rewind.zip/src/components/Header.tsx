import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, Database, Menu, X, Search, Bell, Radio, Rewind } from 'lucide-react';
import { toggleAudioMute, getIsMuted, playRetroClickSound } from '../utils/audio';
import { Profile } from '../types';

interface HeaderProps {
  currentUser: Profile;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSupabaseModal: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  activeTab: _activeTab,
  setActiveTab,
  onOpenSupabaseModal,
  searchQuery,
  setSearchQuery,
  mobileMenuOpen,
  setMobileMenuOpen
}) => {
  const [muted, setMuted] = useState<boolean>(getIsMuted());
  const [showNotifications, setShowNotifications] = useState<boolean>(false);

  const handleMuteToggle = () => {
    const isNowMuted = toggleAudioMute();
    setMuted(isNowMuted);
    if (!isNowMuted) {
      playRetroClickSound();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b-2 border-[#319795] text-slate-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">

          {/* Left: Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(!mobileMenuOpen);
                playRetroClickSound();
              }}
              className="lg:hidden p-2 text-[#319795] hover:text-[#D53F8C] focus:outline-none focus:ring-2 focus:ring-[#319795] rounded-lg"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <div
              onClick={() => {
                setActiveTab('feed');
                playRetroClickSound();
              }}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <div className="w-10 h-10 bg-[#D53F8C] flex items-center justify-center rounded-lg shadow-[4px_4px_0px_0px_#319795] group-hover:translate-x-0.5 group-hover:translate-y-0.5 transition-transform">
                <Rewind className="w-6 h-6 text-white fill-white" />
              </div>

              <div>
                <h1 className="text-xl sm:text-2xl font-black tracking-tighter italic leading-none drop-shadow-sm">
                  <span className="text-[#319795]">RE</span>
                  <span className="text-[#D53F8C]">WIND</span>
                </h1>
                <span className="hidden sm:inline-block mt-0.5 px-1.5 py-0.2 text-[9px] font-mono font-bold bg-[#E6FFFA] border border-[#319795] text-[#319795] rounded uppercase tracking-wider">
                  90s & 2000s Nostalgia
                </span>
              </div>
            </div>
          </div>

          {/* Center: Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#319795]" />
              <input
                type="text"
                placeholder="Search memories (e.g. Surge, Razr)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-full pl-10 pr-4 py-1.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D53F8C] transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#D53F8C] hover:underline font-bold"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Supabase SQL Schema Info Button */}
            <button
              onClick={() => {
                onOpenSupabaseModal();
                playRetroClickSound();
              }}
              title="View Supabase Database Schema DDL"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border-2 border-[#319795] hover:bg-[#E6FFFA] text-[#319795] rounded-lg text-xs font-mono font-bold transition-all shadow-[2px_2px_0px_0px_#D53F8C]"
            >
              <Database className="w-3.5 h-3.5 text-[#319795]" />
              <span className="hidden sm:inline">Supabase Schema</span>
            </button>

            {/* Retro Sound Synth Toggle */}
            <button
              onClick={handleMuteToggle}
              title={muted ? 'Enable Retro Web Audio Sounds' : 'Mute Sound Effects'}
              className={`p-2 rounded-lg border-2 transition-all shadow-[2px_2px_0px_0px_#319795] ${
                muted
                  ? 'bg-slate-100 border-slate-300 text-slate-400'
                  : 'bg-white border-[#319795] text-[#319795] hover:bg-[#E6FFFA]'
              }`}
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#D53F8C] animate-pulse" />}
            </button>

            {/* Notifications Button */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  playRetroClickSound();
                }}
                className="p-2 text-[#319795] bg-white hover:bg-[#E6FFFA] border-2 border-[#319795] rounded-lg shadow-[2px_2px_0px_0px_#319795] transition-all relative"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#D53F8C] rounded-full ring-2 ring-white" />
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white border-2 border-[#319795] rounded-xl shadow-[4px_4px_0px_0px_#D53F8C] z-50 p-3">
                  <div className="flex items-center justify-between border-b-2 border-teal-100 pb-2 mb-2">
                    <span className="font-bold text-xs uppercase tracking-wider text-[#319795] flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#D53F8C]" /> Recent Buzz
                    </span>
                    <button
                      onClick={() => setShowNotifications(false)}
                      className="text-xs text-slate-400 hover:text-[#D53F8C] font-bold"
                    >
                      Close
                    </button>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2 bg-[#F0FFF4] rounded-lg border border-[#319795]">
                      <span className="font-bold text-[#319795]">Alex PixelPioneer</span> commented on your Tamagotchi memory.
                      <div className="text-[10px] text-slate-500 mt-1">10m ago</div>
                    </div>
                    <div className="p-2 bg-[#F0FFF4] rounded-lg border border-[#319795]">
                      <span className="font-bold text-[#D53F8C]">90s Arcade Night</span> meetup updated attendees! 4 new people joined.
                      <div className="text-[10px] text-slate-500 mt-1">1h ago</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* User Profile Quick Access */}
            <button
              onClick={() => {
                setActiveTab('profile');
                playRetroClickSound();
              }}
              className="flex items-center gap-2 p-1 pr-2 rounded-full bg-white hover:bg-[#E6FFFA] border-2 border-[#319795] shadow-[2px_2px_0px_0px_#319795] transition-all group"
            >
              <img
                src={currentUser.avatar_url}
                alt={currentUser.username}
                className="w-7 h-7 rounded-full object-cover ring-2 ring-[#D53F8C]"
              />
              <span className="hidden xl:inline text-xs font-bold text-[#319795] max-w-[100px] truncate">
                {currentUser.username}
              </span>
            </button>

          </div>
        </div>
      </div>
    </header>
  );
};
