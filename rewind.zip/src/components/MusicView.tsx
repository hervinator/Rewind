import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Disc, Volume2, Sparkles, Plus, Radio, Flame, ListMusic, Music, Heart, Check } from 'lucide-react';
import { playRetroClickSound } from '../utils/audio';

interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: string;
  genre: string;
  duration: string;
  cover_url: string;
  freqPattern: number[];
}

const NOSTALGIA_TRACKS: Track[] = [
  {
    id: 'tr_1',
    title: 'All the Small Things',
    artist: 'Blink-182',
    album: 'Enema of the State',
    year: '1999',
    genre: 'Pop Punk',
    duration: '2:47',
    cover_url: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80',
    freqPattern: [60, 85, 95, 70, 90, 80, 65, 95]
  },
  {
    id: 'tr_2',
    title: 'In the End',
    artist: 'Linkin Park',
    album: 'Hybrid Theory',
    year: '2000',
    genre: 'Nu Metal',
    duration: '3:36',
    cover_url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=400&q=80',
    freqPattern: [90, 75, 80, 95, 70, 85, 90, 100]
  },
  {
    id: 'tr_3',
    title: 'Smells Like Teen Spirit',
    artist: 'Nirvana',
    album: 'Nevermind',
    year: '1991',
    genre: 'Grunge',
    duration: '5:01',
    cover_url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
    freqPattern: [100, 90, 80, 85, 90, 95, 75, 85]
  },
  {
    id: 'tr_4',
    title: 'Complicated',
    artist: 'Avril Lavigne',
    album: 'Let Go',
    year: '2002',
    genre: 'Y2K Pop-Rock',
    duration: '4:05',
    cover_url: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=400&q=80',
    freqPattern: [50, 65, 75, 80, 70, 85, 60, 75]
  },
  {
    id: 'tr_5',
    title: 'Blue (Da Ba Dee)',
    artist: 'Eiffel 65',
    album: 'Europop',
    year: '1999',
    genre: 'Eurodance',
    duration: '4:43',
    cover_url: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=400&q=80',
    freqPattern: [70, 90, 100, 85, 95, 90, 80, 90]
  },
  {
    id: 'tr_6',
    title: 'I Want It That Way',
    artist: 'Backstreet Boys',
    album: 'Millennium',
    year: '1999',
    genre: 'Boy Band',
    duration: '3:33',
    cover_url: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=400&q=80',
    freqPattern: [40, 55, 70, 65, 80, 75, 60, 70]
  }
];

export const MusicView: React.FC = () => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(80);
  const [mixtapeTracks, setMixtapeTracks] = useState<string[]>(['tr_1', 'tr_2']);
  const [cdName, setCdName] = useState<string>('My Summer 2003 Roadtrip Mix CD-R');
  const [isCDBurned, setIsCDBurned] = useState<boolean>(false);
  const [eqBars, setEqBars] = useState<number[]>([40, 60, 80, 50, 70, 90, 65, 85]);

  const activeTrack = NOSTALGIA_TRACKS[currentTrackIndex];
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);

  // Equalizer animation
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setEqBars(activeTrack.freqPattern.map((val) => Math.min(100, Math.max(15, val + (Math.random() * 40 - 20)))));
      }, 150);
    } else {
      setEqBars([20, 25, 20, 30, 20, 25, 20, 30]);
    }

    return () => clearInterval(interval);
  }, [isPlaying, activeTrack]);

  // Audio Playback Synth simulation
  const startSynth = (freq: number) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (oscRef.current) {
        oscRef.current.stop();
        oscRef.current.disconnect();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime((volume / 100) * 0.08, ctx.currentTime);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      oscRef.current = osc;
      gainRef.current = gain;
    } catch (e) {
      console.error(e);
    }
  };

  const stopSynth = () => {
    if (oscRef.current) {
      try {
        oscRef.current.stop();
        oscRef.current.disconnect();
      } catch (e) {}
      oscRef.current = null;
    }
  };

  const togglePlay = () => {
    playRetroClickSound();
    if (isPlaying) {
      setIsPlaying(false);
      stopSynth();
    } else {
      setIsPlaying(true);
      // Play retro melody synth tone based on track index
      startSynth(220 + currentTrackIndex * 50);
    }
  };

  const handleNext = () => {
    playRetroClickSound();
    const nextIdx = (currentTrackIndex + 1) % NOSTALGIA_TRACKS.length;
    setCurrentTrackIndex(nextIdx);
    if (isPlaying) {
      startSynth(220 + nextIdx * 50);
    }
  };

  const handlePrev = () => {
    playRetroClickSound();
    const prevIdx = (currentTrackIndex - 1 + NOSTALGIA_TRACKS.length) % NOSTALGIA_TRACKS.length;
    setCurrentTrackIndex(prevIdx);
    if (isPlaying) {
      startSynth(220 + prevIdx * 50);
    }
  };

  const toggleMixtapeTrack = (trackId: string) => {
    playRetroClickSound();
    if (mixtapeTracks.includes(trackId)) {
      setMixtapeTracks(mixtapeTracks.filter((id) => id !== trackId));
    } else {
      setMixtapeTracks([...mixtapeTracks, trackId]);
    }
  };

  const handleBurnCD = () => {
    playRetroClickSound();
    setIsCDBurned(true);
    setTimeout(() => {
      setIsCDBurned(false);
    }, 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white border-2 border-[#319795] rounded-xl p-6 shadow-[4px_4px_0px_0px_#D53F8C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6FFFA] border border-[#319795] text-[#319795] text-xs font-mono font-bold mb-1.5">
            <Radio className="w-3.5 h-3.5 text-[#D53F8C]" /> Winamp & iPod Retro Music Station
          </div>
          <h1 className="text-2xl font-black text-[#319795] tracking-tight">
            90s & Y2K Nostalgia Music Player 🎵
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
            "Winamp - It really whips the llama’s ass!" Stream iconic pop-punk, nu-metal, boy band, and Y2K bangers with an interactive retro visualizer & CD-R burner!
          </p>
        </div>
      </div>

      {/* Main Player Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Winamp / Retro Player Skin Box */}
        <div className="lg:col-span-2 bg-[#1A202C] border-4 border-[#319795] rounded-xl p-6 shadow-[6px_6px_0px_0px_#D53F8C] text-teal-400 font-mono space-y-5">
          
          {/* Top Title LCD Bar */}
          <div className="bg-black border-2 border-[#319795] rounded-lg p-3 flex items-center justify-between shadow-inner">
            <div className="flex items-center gap-3 overflow-hidden">
              <Disc className={`w-6 h-6 text-[#D53F8C] shrink-0 ${isPlaying ? 'animate-spin' : ''}`} />
              <div className="truncate">
                <div className="text-xs font-bold text-emerald-400 truncate flex items-center gap-2">
                  <span>WINAMP v2.91</span>
                  <span className="text-[10px] text-[#D53F8C] bg-[#D53F8C]/20 px-1.5 rounded">128kbps stereo</span>
                </div>
                <div className="text-sm font-black text-white truncate">
                  {currentTrackIndex + 1}. {activeTrack.artist} - {activeTrack.title} ({activeTrack.year})
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-lg font-black text-emerald-400 font-mono tracking-widest">
                {isPlaying ? '01:42' : '00:00'}
              </div>
              <div className="text-[10px] text-slate-400">Total: {activeTrack.duration}</div>
            </div>
          </div>

          {/* Equalizer Visualizer Screen */}
          <div className="bg-black border-2 border-slate-700 rounded-lg p-4 relative h-32 flex items-end justify-between gap-2 overflow-hidden">
            {/* Background Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(to_bottom,#000000_1px,transparent_1px)] bg-[size:100%_8px] opacity-40 pointer-events-none" />
            
            {eqBars.map((height, idx) => (
              <div key={idx} className="flex-1 flex flex-col justify-end h-full z-10 items-center">
                <div
                  style={{ height: `${height}%` }}
                  className="w-full rounded-t transition-all duration-150 bg-gradient-to-t from-[#319795] via-emerald-400 to-[#D53F8C]"
                />
                <span className="text-[9px] text-slate-500 mt-1">{idx * 2 + 1}kHz</span>
              </div>
            ))}
          </div>

          {/* Player Main Controls Bar */}
          <div className="bg-[#2D3748] border-2 border-[#319795] rounded-lg p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrev}
                className="p-3 bg-[#319795] hover:bg-teal-600 text-white rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all"
                title="Previous Track"
              >
                <SkipBack className="w-5 h-5" />
              </button>

              <button
                onClick={togglePlay}
                className="p-4 bg-[#D53F8C] hover:bg-pink-700 text-white rounded-xl shadow-[3px_3px_0px_0px_#319795] transition-all transform hover:scale-105"
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 fill-white" />}
              </button>

              <button
                onClick={handleNext}
                className="p-3 bg-[#319795] hover:bg-teal-600 text-white rounded-lg shadow-[2px_2px_0px_0px_#D53F8C] transition-all"
                title="Next Track"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-3 w-full sm:w-48 bg-black/40 p-2 rounded-lg border border-slate-700">
              <Volume2 className="w-4 h-4 text-[#319795] shrink-0" />
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => {
                  setVolume(Number(e.target.value));
                  if (gainRef.current && audioCtxRef.current) {
                    gainRef.current.gain.setValueAtTime((Number(e.target.value) / 100) * 0.08, audioCtxRef.current.currentTime);
                  }
                }}
                className="w-full accent-[#D53F8C] cursor-pointer"
              />
              <span className="text-xs text-emerald-400 font-bold w-8 text-right">{volume}%</span>
            </div>
          </div>

          {/* Playlist Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-[#319795] uppercase px-1">
              <span>Nostalgia Tracklist</span>
              <span>Click to Play</span>
            </div>

            <div className="divide-y divide-slate-800 bg-black/60 rounded-lg border border-slate-800 overflow-hidden max-h-56 overflow-y-auto">
              {NOSTALGIA_TRACKS.map((track, idx) => {
                const isActive = idx === currentTrackIndex;

                return (
                  <button
                    key={track.id}
                    onClick={() => {
                      setCurrentTrackIndex(idx);
                      setIsPlaying(true);
                      startSynth(220 + idx * 50);
                      playRetroClickSound();
                    }}
                    className={`w-full p-3 text-left flex items-center justify-between text-xs transition-all ${
                      isActive ? 'bg-[#319795]/20 text-emerald-400 font-bold border-l-4 border-[#D53F8C]' : 'text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-4 text-center font-mono text-slate-500">{idx + 1}</span>
                      <div>
                        <div className="font-bold text-slate-100">{track.title}</div>
                        <div className="text-[10px] text-slate-400">{track.artist} • {track.album}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-[#319795] font-bold">
                        {track.genre}
                      </span>
                      <span className="font-mono text-slate-500">{track.duration}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* CD-R Mixtape Burner Tool */}
        <div className="lg:col-span-1 bg-white border-2 border-[#319795] rounded-xl p-5 shadow-[4px_4px_0px_0px_#319795] flex flex-col justify-between space-y-4">
          
          <div>
            <div className="flex items-center gap-2 border-b-2 border-teal-100 pb-3">
              <Disc className="w-5 h-5 text-[#D53F8C]" />
              <h3 className="font-black text-slate-900 text-base">CD-R Mixtape Studio 700MB</h3>
            </div>

            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Select your favorite songs below and burn a sharpie-labeled custom CD-R to listen in your car discman!
            </p>

            {/* CD Label Input */}
            <div className="mt-4 space-y-2">
              <label className="block text-xs font-bold text-[#319795]">Mixtape Title (Sharpie Label):</label>
              <input
                type="text"
                value={cdName}
                onChange={(e) => setCdName(e.target.value)}
                className="w-full bg-[#F0FFF4] border-2 border-[#319795] rounded-lg px-3 py-2 text-xs text-slate-800 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-[#D53F8C]"
              />
            </div>

            {/* Song Checkboxes */}
            <div className="mt-4 space-y-2">
              <span className="text-xs font-bold text-slate-700">Add Tracks to CD-R ({mixtapeTracks.length}/8):</span>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {NOSTALGIA_TRACKS.map((t) => {
                  const isAdded = mixtapeTracks.includes(t.id);

                  return (
                    <button
                      key={t.id}
                      onClick={() => toggleMixtapeTrack(t.id)}
                      className={`w-full p-2 text-left text-xs rounded-lg border transition-all flex items-center justify-between ${
                        isAdded
                          ? 'bg-[#E6FFFA] border-[#319795] text-[#319795] font-bold'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-teal-50'
                      }`}
                    >
                      <span className="truncate">{t.title} - {t.artist}</span>
                      {isAdded && <Check className="w-4 h-4 text-[#D53F8C] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Burn Button */}
          <div className="pt-3 border-t-2 border-teal-100">
            {isCDBurned ? (
              <div className="p-3 bg-[#E6FFFA] border-2 border-[#319795] rounded-lg text-center space-y-1">
                <Sparkles className="w-5 h-5 text-[#D53F8C] mx-auto animate-bounce" />
                <div className="text-xs font-black text-[#319795]">🔥 CD-R Successfully Burned!</div>
                <div className="text-[10px] text-slate-600 font-mono italic">Labeling "{cdName}" with sharpie...</div>
              </div>
            ) : (
              <button
                onClick={handleBurnCD}
                disabled={mixtapeTracks.length === 0}
                className="w-full py-3 bg-[#D53F8C] hover:bg-pink-700 disabled:opacity-50 text-white font-black text-xs rounded-lg shadow-[2px_2px_0px_0px_#319795] transition-all flex items-center justify-center gap-2"
              >
                <Flame className="w-4 h-4" />
                <span>Burn CD-R Mixtape ({mixtapeTracks.length} tracks)</span>
              </button>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
