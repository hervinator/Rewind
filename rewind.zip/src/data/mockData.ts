import { Profile, Post, Meetup, MarketplaceItem, Community, Conversation, Message, TimeCapsuleItem, QuizQuestion } from '../types';

export const CURRENT_USER: Profile = {
  id: 'user_current',
  username: 'Sarah "x3_CyberGoth_x3"',
  handle: '@sarah_y2k',
  avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  banner_url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
  era_preference: 'Y2K Teen',
  bio: '90s kid, Y2K survivor. Proud owner of 412 AIM buddy icons, 3 Tamagotchis (all fed today), and an original Lime Green Game Boy Color. ~* BRB MSN *~',
  location: 'Austin, TX (formerly 1999)',
  favorite_childhood_media: {
    favorite_show: 'Hey Arnold! / Buffy',
    favorite_game: 'Super Smash Bros 64',
    favorite_snack: 'Dunkaroos & Surge',
    favorite_album: 'Blink-182 - Enema of the State'
  },
  badges: ['AIM Power User', 'Blockbuster Gold Member', 'Snake II Champ', 'Y2K Survivor'],
  aim_away_message: '~* Out at the arcade bar with the squad. Leave a message after the beep *~',
  aim_status: 'online',
  created_at: '1999-12-31T23:59:59Z'
};

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post_1',
    user_id: 'user_tamagotchi',
    author: {
      username: 'Alex "PixelPioneer"',
      handle: '@alex_retro95',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      era_preference: '90s Kid'
    },
    content: 'Who remembers the absolute PANIC when your Tamagotchi started beeping in the middle of 5th-period math class?! You had to sneak it under your desk to clean up the virtual poop before the teacher caught you. 😂 🥚 #Tamagotchi #90sKidProblems',
    image_url: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?auto=format&fit=crop&w=800&q=80',
    category: 'Tech & Toys',
    decade_tag: '90s',
    likes_count: 342,
    user_liked: true,
    comments_count: 28,
    comments: [
      {
        id: 'c1',
        post_id: 'post_1',
        user_id: 'user_2',
        author: {
          username: 'Jessica V.',
          handle: '@jess_blockbuster',
          avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
          era_preference: '90s Kid'
        },
        content: 'I literally paid my little brother $5 to keep mine alive while I went to summer camp! Worth every penny.',
        created_at: new Date(Date.now() - 1000 * 60 * 45).toISOString()
      },
      {
        id: 'c2',
        post_id: 'post_1',
        user_id: 'user_3',
        author: {
          username: 'Dave "N64"',
          handle: '@dave_goldeneye',
          avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
          era_preference: 'Late 90s / Early 00s Hybrid'
        },
        content: 'Pressing the reset button with a paperclip when it died... peak trauma for 9 year old me!',
        created_at: new Date(Date.now() - 1000 * 60 * 20).toISOString()
      }
    ],
    created_at: new Date(Date.now() - 1000 * 60 * 90).toISOString()
  },
  {
    id: 'post_2',
    user_id: 'user_aim',
    author: {
      username: 'Melissa "xX_EmoPrincess_Xx"',
      handle: '@melissa_y2k',
      avatar_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
      era_preference: 'Y2K Teen'
    },
    content: 'Setting your AIM Away Message to cryptic Dashboard Confessional or Linkin Park lyrics so your crush knew you were deep and misunderstood... `~* I am thinking of you in shades of blue *~ [[ BRB at soccer practice ]]` 💬✨',
    image_url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    category: 'Nostalgia',
    decade_tag: '2000s',
    likes_count: 519,
    user_liked: false,
    comments_count: 42,
    comments: [
      {
        id: 'c3',
        post_id: 'post_2',
        user_id: 'user_current',
        author: {
          username: CURRENT_USER.username,
          handle: CURRENT_USER.handle,
          avatar_url: CURRENT_USER.avatar_url,
          era_preference: CURRENT_USER.era_preference
        },
        content: 'And signing off and back on 5 times in a row just so your buddy icon popped up in their bottom right corner notification!',
        created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString()
      }
    ],
    created_at: new Date(Date.now() - 1000 * 60 * 240).toISOString()
  },
  {
    id: 'post_3',
    user_id: 'user_blockbuster',
    author: {
      username: 'Marcus "TapeRewinder"',
      handle: '@marcus_vhs',
      avatar_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80',
      era_preference: '90s Kid'
    },
    content: 'Friday night ritual: Mom takes us to Blockbuster Video. The smell of hot popcorn, browsing the blue plastic tape shelves for 45 minutes, picking a SNES game based purely on the box art, and grabbing a box of Buncha Crunch. "Be Kind, Rewind!" 📼🍿',
    image_url: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    category: 'Movies & TV',
    decade_tag: '90s',
    likes_count: 884,
    user_liked: true,
    comments_count: 67,
    comments: [],
    created_at: new Date(Date.now() - 1000 * 60 * 500).toISOString()
  },
  {
    id: 'post_4',
    user_id: 'user_gaming',
    author: {
      username: 'Brandon "OddjobBanned"',
      handle: '@brandon_n64',
      avatar_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
      era_preference: '90s Kid'
    },
    content: 'Rules of the house in 1998: 1. No picking Oddjob in GoldenEye 007. 2. No screen peeping. 3. Blowing into the cartridge fixes 100% of graphic glitches. 🎮 Who still has their gray N64 controller with the loose joystick?',
    image_url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
    category: 'Gaming',
    decade_tag: '90s',
    likes_count: 620,
    user_liked: false,
    comments_count: 35,
    comments: [],
    created_at: new Date(Date.now() - 1000 * 60 * 1200).toISOString()
  },
  {
    id: 'post_5',
    user_id: 'user_ipod',
    author: {
      username: 'Chloe "ClickWheel"',
      handle: '@chloe_mp3',
      avatar_url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80',
      era_preference: 'Y2K Teen'
    },
    content: 'Found my old 30GB iPod Video in a box! The satisfying *click click click* sound of the wheel wheel, spending hours organizing Limewire tags in iTunes, and watching Shrek on a 2-inch screen during bus rides. Pure magic 🎧⚡',
    image_url: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
    category: 'Music',
    decade_tag: '2000s',
    likes_count: 412,
    user_liked: true,
    comments_count: 19,
    comments: [],
    created_at: new Date(Date.now() - 1000 * 60 * 1800).toISOString()
  }
];

export const INITIAL_MEETUPS: Meetup[] = [
  {
    id: 'meetup_1',
    title: '90s Arcade Bar & Pinball Tournament Night',
    description: 'Join local 90s kids for free-play retro arcade cabinets (Mortal Kombat II, Street Fighter II Turbo, Pac-Man, TMNT Arcade) + 90s music video playlist & craft brews! Wear your best neon windbreaker or flannel.',
    category: 'Arcade & Gaming',
    date: '2026-08-14',
    time: '7:30 PM',
    location: '1UP Retro Bar & Lounge',
    city: 'Austin, TX',
    organizer: {
      id: 'user_arcade',
      username: 'Dave "HighScore"',
      avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
      handle: '@dave_arcade'
    },
    attendees_count: 34,
    user_is_attending: true,
    attendees_avatars: [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=100&q=80'
    ],
    max_attendees: 50,
    cover_image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-28T10:00:00Z'
  },
  {
    id: 'meetup_2',
    title: 'Super Smash Bros 64 & Mario Kart 64 Couch Tournament',
    description: '4 CRT TVs, 16 original controllers, 0 screen peeping allowed! Double elimination tournament for GoldenEye 007, Smash 64, and Mario Kart. Pizza & Capri Suns provided!',
    category: 'Arcade & Gaming',
    date: '2026-08-22',
    time: '6:00 PM',
    location: 'Retro Game Exchange Rec Room',
    city: 'Round Rock, TX',
    organizer: {
      id: 'user_smash',
      username: 'Brandon "FalconPunch"',
      avatar_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
      handle: '@brandon_n64'
    },
    attendees_count: 18,
    user_is_attending: false,
    attendees_avatars: [
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=100&q=80',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=100&q=80'
    ],
    max_attendees: 32,
    cover_image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-30T14:30:00Z'
  },
  {
    id: 'meetup_3',
    title: '2000s Emo & Pop-Punk Sing-Along Night',
    description: 'Screaming Paramore, Fall Out Boy, Blink-182, My Chemical Romance, and Panic! at the Disco at the top of our lungs. Eyeliner and studded belts optional but highly encouraged.',
    category: 'Music & Concerts',
    date: '2026-08-28',
    time: '9:00 PM',
    location: 'The Black Cat Lounge',
    city: 'Austin, TX',
    organizer: {
      id: 'user_emo',
      username: 'Melissa "xX_EmoPrincess_Xx"',
      avatar_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
      handle: '@melissa_y2k'
    },
    attendees_count: 45,
    user_is_attending: true,
    attendees_avatars: [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80'
    ],
    max_attendees: 75,
    cover_image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-25T11:00:00Z'
  },
  {
    id: 'meetup_4',
    title: 'Saturday Morning Cartoons & Cereal Bar Hangout',
    description: 'Unlimited bowls of French Toast Crunch, Dunkaroos, Reese’s Puffs, and SunnyD while watching Rugrats, Sailor Moon, Pokemon, and X-Men Animated on CRT monitors in beanbag chairs.',
    category: 'Food & Snacks',
    date: '2026-09-05',
    time: '10:00 AM',
    location: 'Nostalgia Cafe & Diner',
    city: 'Austin, TX',
    organizer: {
      id: 'user_cartoons',
      username: 'Jessica V.',
      avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
      handle: '@jess_blockbuster'
    },
    attendees_count: 27,
    user_is_attending: false,
    attendees_avatars: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80'
    ],
    max_attendees: 40,
    cover_image: 'https://images.unsplash.com/photo-1528740561666-dc2479dc08ab?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-08-01T08:00:00Z'
  }
];

export const INITIAL_MARKETPLACE: MarketplaceItem[] = [
  {
    id: 'item_1',
    title: 'Original Game Boy Color (Lime Green) - Tested & Working',
    description: '1998 Nintendo Game Boy Color in rare Lime Green. Clean screen, speaker crisp and loud, battery compartment spotless. Includes Pokemon Yellow cartridge!',
    price: 125,
    condition: 'Gently Used',
    category: 'Gaming',
    decade: '90s',
    status: 'Available',
    seller: {
      id: 'seller_1',
      username: 'Alex "PixelPioneer"',
      handle: '@alex_retro95',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      rating: 4.9
    },
    location: 'Austin, TX',
    image_url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-29T16:00:00Z'
  },
  {
    id: 'item_2',
    title: 'Tiger Electronics Furby (1998 Original - Black & White)',
    description: 'Fully functional original 1998 Furby! Speaks Furbish and English, responds to tummy tickles and light sensors. Eyes open and close smoothly.',
    price: 65,
    condition: 'Like New',
    category: 'Toys & Collectibles',
    decade: '90s',
    status: 'Available',
    seller: {
      id: 'seller_2',
      username: 'Jessica V.',
      handle: '@jess_blockbuster',
      avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
      rating: 5.0
    },
    location: 'Dallas, TX',
    image_url: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-31T12:00:00Z'
  },
  {
    id: 'item_3',
    title: 'Official Blockbuster Video Member Card Keychain & Tape Holder',
    description: 'Authentic 90s Blockbuster Video memorabilia! Laminated membership card holder plus nostalgic blue VHS plastic tape storage case.',
    price: 35,
    condition: 'Mint in Box',
    category: 'Toys & Collectibles',
    decade: '90s',
    status: 'Available',
    seller: {
      id: 'seller_3',
      username: 'Marcus "TapeRewinder"',
      handle: '@marcus_vhs',
      avatar_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=200&q=80',
      rating: 4.8
    },
    location: 'Houston, TX',
    image_url: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-30T09:00:00Z'
  },
  {
    id: 'item_4',
    title: 'Apple iPod Video 30GB (Black - 5.5 Gen Wolfson DAC)',
    description: 'Refurbished 5.5 Gen iPod Video with brand new 3000mAh battery upgrade and 128GB flash storage card! Pre-loaded with classic 2000s playlists.',
    price: 150,
    condition: 'Refurbished',
    category: 'Retro Tech',
    decade: '2000s',
    status: 'Available',
    seller: {
      id: 'seller_4',
      username: 'Chloe "ClickWheel"',
      handle: '@chloe_mp3',
      avatar_url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
      rating: 5.0
    },
    location: 'San Antonio, TX',
    image_url: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-27T18:00:00Z'
  },
  {
    id: 'item_5',
    title: 'Complete Goosebumps Original Series 1-62 Book Set (R.L. Stine)',
    description: 'Full collection of original 90s Goosebumps paperbacks with textured covers! Includes Welcome to Dead House, Monster Blood, and Night of the Living Dummy.',
    price: 180,
    condition: 'Well Loved',
    category: 'Toys & Collectibles',
    decade: '90s',
    status: 'Available',
    seller: {
      id: 'seller_5',
      username: 'Brandon "OddjobBanned"',
      handle: '@brandon_n64',
      avatar_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
      rating: 4.7
    },
    location: 'Austin, TX',
    image_url: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80',
    created_at: '2026-07-26T11:00:00Z'
  }
];

export const INITIAL_COMMUNITIES: Community[] = [
  {
    id: 'comm_1',
    name: 'N64 & PS1 Golden Era Gamers',
    description: 'For everyone who remembers local split-screen multiplayer, memory cards, cheat codes in gaming mags, and blowing into cartridges.',
    category: 'Gaming',
    member_count: 4820,
    icon: 'Gamepad2',
    cover_image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
    user_is_member: true,
    tags: ['N64', 'PlayStation', 'Dreamcast', 'Multiplayer'],
    created_at: '2025-01-15T00:00:00Z'
  },
  {
    id: 'comm_2',
    name: '90s Nickelodeon & Cartoon Network Club',
    description: 'Rugrats, Hey Arnold!, Dexter’s Lab, Courage the Cowardly Dog, Powerpuff Girls, and Snick Saturday nights!',
    category: 'Movies & TV',
    member_count: 6190,
    icon: 'Tv',
    cover_image: 'https://images.unsplash.com/photo-1528740561666-dc2479dc08ab?auto=format&fit=crop&w=800&q=80',
    user_is_member: true,
    tags: ['Cartoons', 'Nicktoons', 'Toonami', '90sTV'],
    created_at: '2025-02-10T00:00:00Z'
  },
  {
    id: 'comm_3',
    name: 'AIM & MSN Away Message Writers Guild',
    description: 'Appreciating the lost art form of typing cryptic lyrics, HTML formatting, colored fonts, and bolding your crush’s initials.',
    category: 'Nostalgia',
    member_count: 3240,
    icon: 'MessageSquareText',
    cover_image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    user_is_member: false,
    tags: ['AIM', 'MSN', 'AwayMessages', 'Y2K'],
    created_at: '2025-03-01T00:00:00Z'
  },
  {
    id: 'comm_4',
    name: 'Cassette, CD & Physical Media Collectors',
    description: 'Burning custom mixtapes on CD-Rs, writing tracks with Sharpie markers, MP3 players, and cassette tape rewinding pencil tricks.',
    category: 'Music',
    member_count: 2950,
    icon: 'Disc',
    cover_image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
    user_is_member: true,
    tags: ['CDs', 'Cassettes', 'Walkman', 'Mixtapes'],
    created_at: '2025-03-20T00:00:00Z'
  }
];

export const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv_1',
    participant: {
      id: 'seller_1',
      username: 'Alex "PixelPioneer"',
      handle: '@alex_retro95',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      status: 'online',
      away_message: '~* Playing Super Mario World on SNES. Ping me! *~'
    },
    last_message: 'Hey Sarah! The Game Boy Color is ready for pickup or shipping anytime.',
    last_message_time: '10:42 AM',
    unread_count: 1
  },
  {
    id: 'conv_2',
    participant: {
      id: 'user_emo',
      username: 'Melissa "xX_EmoPrincess_Xx"',
      handle: '@melissa_y2k',
      avatar_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
      status: 'away',
      away_message: 'brb listening to Jimmy Eat World'
    },
    last_message: 'Are you coming to the pop-punk sing-along night on the 28th?!',
    last_message_time: 'Yesterday',
    unread_count: 0
  }
];

export const INITIAL_MESSAGES: Record<string, Message[]> = {
  conv_1: [
    {
      id: 'm1',
      conversation_id: 'conv_1',
      sender_id: 'user_current',
      sender_name: CURRENT_USER.username,
      sender_avatar: CURRENT_USER.avatar_url,
      content: 'Hey Alex! Saw your Lime Green Game Boy Color listing in the marketplace.',
      timestamp: '10:30 AM',
      is_me: true
    },
    {
      id: 'm2',
      conversation_id: 'conv_1',
      sender_id: 'user_current',
      sender_name: CURRENT_USER.username,
      sender_avatar: CURRENT_USER.avatar_url,
      content: 'Does Pokemon Yellow still hold save files properly?',
      timestamp: '10:31 AM',
      is_me: true
    },
    {
      id: 'm3',
      conversation_id: 'conv_1',
      sender_id: 'seller_1',
      sender_name: 'Alex "PixelPioneer"',
      sender_avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      content: 'Hey Sarah! Yes! Replaced the CR2025 save battery last month, so saves like brand new. The Game Boy Color is ready for pickup or shipping anytime.',
      timestamp: '10:42 AM',
      is_me: false
    }
  ]
};

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'How did you handle your internet connection after 8 PM in 1999?',
    options: [
      { text: 'Waiting for Mom to get off the landline phone so dial-up noise could screech.', archetype: '90s Dial-Up Devotee' },
      { text: 'Tying up the single home phone line all night on AIM until someone screamed.', archetype: 'AIM Power User' },
      { text: 'Sneaking to play offline SNES/N64 games when the PC was occupied.', archetype: 'Cartridge Gamer' }
    ]
  },
  {
    id: 2,
    question: 'What was your primary music storage device in high school?',
    options: [
      { text: 'A Sony Discman with 45-second anti-skip protection in my jacket pocket.', archetype: 'Physical Media Enthusiast' },
      { text: 'A chunky iPod Click Wheel stuffed with 3,000 MP3s from Limewire.', archetype: 'Y2K Tech Pioneer' },
      { text: 'Custom cassette mixtapes recorded directly off FM radio countdowns.', archetype: '90s Dial-Up Devotee' }
    ]
  },
  {
    id: 3,
    question: 'Pick your ultimate Friday night snack & movie combo:',
    options: [
      { text: 'Dunkaroos, Surge soda, and a rented Blockbuster VHS of Space Jam.', archetype: '90s Dial-Up Devotee' },
      { text: 'Bagel Bites, SunnyD, and watching TRL on MTV after school.', archetype: 'Y2K Tech Pioneer' },
      { text: 'Pizza Rolls, Mountain Dew, and 4-player GoldenEye 007 on N64.', archetype: 'Cartridge Gamer' }
    ]
  }
];

export const INITIAL_TIME_CAPSULE_ITEMS: TimeCapsuleItem[] = [
  {
    id: 'tc_1',
    title: 'My Favorite 5th Grade School Locker Items',
    memory_text: 'Inside my locker: Gel pens, a foldable paper fortune teller, a Bop It Extreme, and a printout of the lyrics to All Star by Smash Mouth.',
    unlock_date: '2025-01-01',
    is_locked: false,
    created_at: '2000-05-15T00:00:00Z'
  },
  {
    id: 'tc_2',
    title: 'Y2K Bug Survival Predictions & Hopes',
    memory_text: 'Writing this on December 30, 1999! Hoping our family computer doesn’t blow up at midnight. If you are reading this in the future, please tell me we have flying cars!',
    unlock_date: '2026-08-01',
    is_locked: false,
    created_at: '1999-12-30T00:00:00Z'
  },
  {
    id: 'tc_3',
    title: 'Secret Letter to 2030 Me',
    memory_text: 'A locked memory capsule containing my favorite CD tracklist, secret crushes, and my top 3 high scores on Snake II.',
    unlock_date: '2030-01-01',
    is_locked: true,
    created_at: '2026-08-01T00:00:00Z'
  }
];
